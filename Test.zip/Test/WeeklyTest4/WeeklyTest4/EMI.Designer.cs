﻿namespace WeeklyTest4
{
    partial class EMI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.chbDancing = new System.Windows.Forms.CheckBox();
            this.chbOthers = new System.Windows.Forms.CheckBox();
            this.chbSinging = new System.Windows.Forms.CheckBox();
            this.chbReading = new System.Windows.Forms.CheckBox();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.txtMob = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.lblHobbies = new System.Windows.Forms.Label();
            this.lblMobile = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtPeriod = new System.Windows.Forms.TextBox();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.txtLoanTennure = new System.Windows.Forms.TextBox();
            this.txtLoanAmount = new System.Windows.Forms.TextBox();
            this.txtBasic = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblPeriod = new System.Windows.Forms.Label();
            this.lblROI = new System.Windows.Forms.Label();
            this.lblTenure = new System.Windows.Forms.Label();
            this.lblLoan = new System.Windows.Forms.Label();
            this.lblBasicSalary = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1094, 614);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.lblMessage);
            this.tabPage1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1086, 588);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PersonalDetails";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Snow;
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.btnView);
            this.panel1.Controls.Add(this.chbDancing);
            this.panel1.Controls.Add(this.chbOthers);
            this.panel1.Controls.Add(this.chbSinging);
            this.panel1.Controls.Add(this.chbReading);
            this.panel1.Controls.Add(this.dtpDOB);
            this.panel1.Controls.Add(this.rbFemale);
            this.panel1.Controls.Add(this.rbMale);
            this.panel1.Controls.Add(this.cmbDepartment);
            this.panel1.Controls.Add(this.txtMob);
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.txtID);
            this.panel1.Controls.Add(this.lblHobbies);
            this.panel1.Controls.Add(this.lblMobile);
            this.panel1.Controls.Add(this.lblGender);
            this.panel1.Controls.Add(this.lblDOB);
            this.panel1.Controls.Add(this.lblDepartment);
            this.panel1.Controls.Add(this.lblEmail);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblID);
            this.panel1.Location = new System.Drawing.Point(74, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(974, 548);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Bisque;
            this.btnSave.Location = new System.Drawing.Point(496, 500);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(82, 41);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.Bisque;
            this.btnView.Location = new System.Drawing.Point(838, 500);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(82, 41);
            this.btnView.TabIndex = 28;
            this.btnView.Text = "VIEW";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // chbDancing
            // 
            this.chbDancing.AutoSize = true;
            this.chbDancing.Location = new System.Drawing.Point(462, 463);
            this.chbDancing.Name = "chbDancing";
            this.chbDancing.Size = new System.Drawing.Size(74, 20);
            this.chbDancing.TabIndex = 27;
            this.chbDancing.Text = "Dancing";
            this.chbDancing.UseVisualStyleBackColor = true;
            // 
            // chbOthers
            // 
            this.chbOthers.AutoSize = true;
            this.chbOthers.Location = new System.Drawing.Point(615, 463);
            this.chbOthers.Name = "chbOthers";
            this.chbOthers.Size = new System.Drawing.Size(66, 20);
            this.chbOthers.TabIndex = 26;
            this.chbOthers.Text = "Others";
            this.chbOthers.UseVisualStyleBackColor = true;
            // 
            // chbSinging
            // 
            this.chbSinging.AutoSize = true;
            this.chbSinging.Location = new System.Drawing.Point(615, 420);
            this.chbSinging.Name = "chbSinging";
            this.chbSinging.Size = new System.Drawing.Size(70, 20);
            this.chbSinging.TabIndex = 25;
            this.chbSinging.Text = "Singing";
            this.chbSinging.UseVisualStyleBackColor = true;
            // 
            // chbReading
            // 
            this.chbReading.AutoSize = true;
            this.chbReading.Location = new System.Drawing.Point(462, 420);
            this.chbReading.Name = "chbReading";
            this.chbReading.Size = new System.Drawing.Size(74, 20);
            this.chbReading.TabIndex = 24;
            this.chbReading.Text = "Reading";
            this.chbReading.UseVisualStyleBackColor = true;
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(462, 361);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(200, 22);
            this.dtpDOB.TabIndex = 23;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(599, 308);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(69, 20);
            this.rbFemale.TabIndex = 22;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Checked = true;
            this.rbMale.Location = new System.Drawing.Point(462, 306);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(54, 20);
            this.rbMale.TabIndex = 21;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.Items.AddRange(new object[] {
            "HR",
            "Admin",
            "Marketing",
            "Sales"});
            this.cmbDepartment.Location = new System.Drawing.Point(462, 131);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(264, 24);
            this.cmbDepartment.TabIndex = 20;
            this.cmbDepartment.MouseHover += new System.EventHandler(this.cmbDepartment_MouseHover);
            // 
            // txtMob
            // 
            this.txtMob.Location = new System.Drawing.Point(462, 250);
            this.txtMob.Name = "txtMob";
            this.txtMob.Size = new System.Drawing.Size(264, 22);
            this.txtMob.TabIndex = 19;
            this.txtMob.MouseHover += new System.EventHandler(this.txtMob_MouseHover);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(462, 190);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(264, 22);
            this.txtEmail.TabIndex = 18;
            this.txtEmail.MouseHover += new System.EventHandler(this.txtEmail_MouseHover_1);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(462, 76);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(264, 22);
            this.txtName.TabIndex = 17;
            this.txtName.MouseHover += new System.EventHandler(this.txtName_MouseHover);
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(462, 22);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(264, 22);
            this.txtID.TabIndex = 16;
            this.txtID.MouseHover += new System.EventHandler(this.txtID_MouseHover);
            // 
            // lblHobbies
            // 
            this.lblHobbies.AutoSize = true;
            this.lblHobbies.Location = new System.Drawing.Point(41, 424);
            this.lblHobbies.Name = "lblHobbies";
            this.lblHobbies.Size = new System.Drawing.Size(55, 16);
            this.lblHobbies.TabIndex = 15;
            this.lblHobbies.Text = "Hobbies";
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.Location = new System.Drawing.Point(41, 253);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(91, 16);
            this.lblMobile.TabIndex = 14;
            this.lblMobile.Text = "MobileNumber";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(41, 310);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(50, 16);
            this.lblGender.TabIndex = 13;
            this.lblGender.Text = "Gender";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(41, 367);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(36, 16);
            this.lblDOB.TabIndex = 12;
            this.lblDOB.Text = "DOB";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(41, 139);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(75, 16);
            this.lblDepartment.TabIndex = 11;
            this.lblDepartment.Text = "Department";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(41, 196);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(45, 16);
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "Email ";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(41, 82);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(100, 16);
            this.lblName.TabIndex = 9;
            this.lblName.Text = "EmployeeName";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(41, 25);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(78, 16);
            this.lblID.TabIndex = 8;
            this.lblID.Text = "EmployeeID";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.ForeColor = System.Drawing.Color.Maroon;
            this.lblMessage.Location = new System.Drawing.Point(590, 13);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 16);
            this.lblMessage.TabIndex = 29;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1086, 588);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SalaryDetails";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Cornsilk;
            this.panel2.Controls.Add(this.txtPeriod);
            this.panel2.Controls.Add(this.txtRate);
            this.panel2.Controls.Add(this.txtLoanTennure);
            this.panel2.Controls.Add(this.txtLoanAmount);
            this.panel2.Controls.Add(this.txtBasic);
            this.panel2.Controls.Add(this.btnCalculate);
            this.panel2.Controls.Add(this.lblPeriod);
            this.panel2.Controls.Add(this.lblROI);
            this.panel2.Controls.Add(this.lblTenure);
            this.panel2.Controls.Add(this.lblLoan);
            this.panel2.Controls.Add(this.lblBasicSalary);
            this.panel2.Location = new System.Drawing.Point(198, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(635, 461);
            this.panel2.TabIndex = 0;
            // 
            // txtPeriod
            // 
            this.txtPeriod.Location = new System.Drawing.Point(353, 315);
            this.txtPeriod.Name = "txtPeriod";
            this.txtPeriod.Size = new System.Drawing.Size(116, 22);
            this.txtPeriod.TabIndex = 12;
            // 
            // txtRate
            // 
            this.txtRate.Location = new System.Drawing.Point(353, 247);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(116, 22);
            this.txtRate.TabIndex = 11;
            // 
            // txtLoanTennure
            // 
            this.txtLoanTennure.Location = new System.Drawing.Point(353, 179);
            this.txtLoanTennure.Name = "txtLoanTennure";
            this.txtLoanTennure.Size = new System.Drawing.Size(116, 22);
            this.txtLoanTennure.TabIndex = 10;
            // 
            // txtLoanAmount
            // 
            this.txtLoanAmount.Location = new System.Drawing.Point(353, 111);
            this.txtLoanAmount.Name = "txtLoanAmount";
            this.txtLoanAmount.Size = new System.Drawing.Size(116, 22);
            this.txtLoanAmount.TabIndex = 9;
            // 
            // txtBasic
            // 
            this.txtBasic.Location = new System.Drawing.Point(353, 43);
            this.txtBasic.Name = "txtBasic";
            this.txtBasic.Size = new System.Drawing.Size(116, 22);
            this.txtBasic.TabIndex = 7;
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnCalculate.Location = new System.Drawing.Point(254, 390);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(141, 43);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Calculate EMI";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblPeriod
            // 
            this.lblPeriod.AutoSize = true;
            this.lblPeriod.Location = new System.Drawing.Point(92, 322);
            this.lblPeriod.Name = "lblPeriod";
            this.lblPeriod.Size = new System.Drawing.Size(45, 16);
            this.lblPeriod.TabIndex = 5;
            this.lblPeriod.Text = "Period";
            // 
            // lblROI
            // 
            this.lblROI.AutoSize = true;
            this.lblROI.Location = new System.Drawing.Point(92, 253);
            this.lblROI.Name = "lblROI";
            this.lblROI.Size = new System.Drawing.Size(35, 16);
            this.lblROI.TabIndex = 4;
            this.lblROI.Text = "Rate";
            // 
            // lblTenure
            // 
            this.lblTenure.AutoSize = true;
            this.lblTenure.Location = new System.Drawing.Point(89, 184);
            this.lblTenure.Name = "lblTenure";
            this.lblTenure.Size = new System.Drawing.Size(78, 16);
            this.lblTenure.TabIndex = 3;
            this.lblTenure.Text = "Loan Tenure";
            // 
            // lblLoan
            // 
            this.lblLoan.AutoSize = true;
            this.lblLoan.Location = new System.Drawing.Point(89, 115);
            this.lblLoan.Name = "lblLoan";
            this.lblLoan.Size = new System.Drawing.Size(84, 16);
            this.lblLoan.TabIndex = 2;
            this.lblLoan.Text = "Loan Amount";
            // 
            // lblBasicSalary
            // 
            this.lblBasicSalary.AutoSize = true;
            this.lblBasicSalary.Location = new System.Drawing.Point(89, 46);
            this.lblBasicSalary.Name = "lblBasicSalary";
            this.lblBasicSalary.Size = new System.Drawing.Size(82, 16);
            this.lblBasicSalary.TabIndex = 0;
            this.lblBasicSalary.Text = "Basic Salary";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 628);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1122, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(974, 25);
            this.toolStrip1.TabIndex = 31;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 22);
            // 
            // EMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 650);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Name = "EMI";
            this.Text = "EMI";
            this.Load += new System.EventHandler(this.EMI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.CheckBox chbDancing;
        private System.Windows.Forms.CheckBox chbOthers;
        private System.Windows.Forms.CheckBox chbSinging;
        private System.Windows.Forms.CheckBox chbReading;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.TextBox txtMob;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lblHobbies;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtPeriod;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.TextBox txtLoanTennure;
        private System.Windows.Forms.TextBox txtLoanAmount;
        private System.Windows.Forms.TextBox txtBasic;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblPeriod;
        private System.Windows.Forms.Label lblROI;
        private System.Windows.Forms.Label lblTenure;
        private System.Windows.Forms.Label lblLoan;
        private System.Windows.Forms.Label lblBasicSalary;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
    }
}