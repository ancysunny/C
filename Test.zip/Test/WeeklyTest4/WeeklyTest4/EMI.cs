﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WeeklyTest4
{
    public partial class EMI : Form
    {
        public EMI()
        {
            InitializeComponent();
        }
        string EmployeeID;
        string EmployeeName;
        string Department;
        string email;
        string MobileNumber;
        string Gender;
        string DOB;
        string Hobbies = "";
        private void btnView_Click(object sender, EventArgs e)
        {
            

            
            try
            {
                 EmployeeID = txtID.Text.ToString();
                 if (txtID.Text==string.Empty || txtName.Text == string.Empty ||cmbDepartment.Text == string.Empty||txtEmail.Text == string.Empty || txtMob.Text == string.Empty )
                 {
                     lblMessage.Text = "All fields are mandatory!!!";
                     
                 }
                 else
                 {
                     EmployeeID = txtID.Text.ToString();
                     EmployeeName = txtName.Text;
                     Department = cmbDepartment.Text;
                     email = txtEmail.Text;

                     MobileNumber = txtMob.Text.ToString();
                     DOB = dtpDOB.Value.ToString("dd-MM-yyyy");

                     MessageBox.Show("Employee ID : " + txtID.Text + "\n " + "Employee Name :" + txtName.Text + "\n " + "Department :" + cmbDepartment.Text + "\n " + "Email : " + txtEmail.Text + "\n " + "Mobile Number : " + txtMob.Text + "\n " + "DOB : " + DOB + "\n " + "Gender : " + Gender + "\n " + "Hobbies : " + Hobbies );

                 }
                 
            }
            catch
            {
                 lblMessage.Text = "Enter the Details correctly!";
                
            }
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double BasicSalary = 0;
            double DA = 0;
            double GP=0;
            double NetPay=0;
            double LoanTenure = 0;
            double LoanAmount = 0;
            double Payment = 0;
            double InterestRate ;
            int PaymentPeriods = 0;
            try
            {
                BasicSalary = Convert.ToDouble(txtBasic.Text);
                DA = Convert.ToDouble(BasicSalary * 30 / 100);
                GP = Convert.ToDouble(BasicSalary + DA);
                LoanTenure = Convert.ToDouble(txtLoanTennure.Text);
                InterestRate = Convert.ToDouble(txtRate.Text);
                PaymentPeriods = Convert.ToInt32(Convert.ToDouble(txtPeriod.Text) * 12);
                LoanAmount = Convert.ToDouble(txtLoanAmount.Text);
               
                Payment = (LoanAmount * Math.Pow((InterestRate / 12) + 1, (PaymentPeriods)) * InterestRate / 12) / (Math.Pow (InterestRate / 12 + 1, (PaymentPeriods)) - 1);

                NetPay = Convert.ToDouble(GP - Payment);

                MessageBox.Show("Employee ID : " + txtID.Text + "\n " + "Employee Name :" + txtName.Text + "\n " + "Department :" + cmbDepartment.Text + "\n " + "Email : " + txtEmail.Text + "\n " + "Mobile Number : " + txtMob.Text + "\n " + "DOB : " + DOB + "\n " + "Gender : " + Gender + "\n " + "Hobbies : " + Hobbies + "\n \n" +"DA = " + DA + "\n" + "GP = " + GP + "\n" + "EMI = " + Payment + "\n" + "Net Pay = " + NetPay );

            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 100;i++ )
            {
                toolStripProgressBar1.Value = i;
            }


                try
                {

                    if (txtID.Text == string.Empty || txtName.Text == string.Empty || cmbDepartment.Text == string.Empty || txtEmail.Text == string.Empty || txtMob.Text == string.Empty)
                    {
                        lblMessage.Text = "All fields are mandatory!!!";
                    }
                    else
                    {
                        EmployeeID = txtID.Text.ToString();

                        EmployeeName = txtName.Text;

                        Department = cmbDepartment.Text;


                        email = txtEmail.Text;

                        if (!email.Contains('@'))
                        {
                            lblMessage.Text = "Please Enter the valid Email";
                        }


                        MobileNumber = txtMob.Text.ToString();
                        if (txtMob.Text.Length < 10 || txtMob.Text.Length > 10)
                        {
                            lblMessage.Text = "Please Enter the valid Mobile Number";
                        }

                        if (rbMale.Checked)
                        {
                            Gender = "Male";
                        }
                        else
                        {
                            Gender = "Female";
                        }


                        DOB = dtpDOB.Value.ToString("dd-MM-yyyy");

                        if (dtpDOB.Text == string.Empty)
                        {
                            MessageBox.Show("Please Enter the DOB");
                        }
                        if (chbReading.Checked)
                        {
                            Hobbies += "Reading ";
                            chbReading.Enabled = false;
                        }
                        if (chbSinging.Checked)
                        {
                            Hobbies += "Singing ";
                            chbSinging.Enabled = false;
                        }

                        if (chbDancing.Checked)
                        {
                            Hobbies += "Dancing ";
                            chbDancing.Enabled = false;
                        }
                        if (chbOthers.Checked)
                        {
                            Hobbies += "Others";
                            chbOthers.Enabled = false;
                        }

                        lblMessage.Text = "Details saved successfully...!";
                    }



                }
                catch (FormatException fe)
                {
                    lblMessage.Text = "Enter the details in correct format!";
                }

                catch
                {
                    lblMessage.Text = "Enter the Details correctly!";

                }

           
        }

        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
           
        }

        private void EMI_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }
        private void txtID_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter the Employee ID";
        }
        private void txtName_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter the Employee Name";
        }
              
        
        private void cmbDepartment_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Select Department";
        }

        private void txtEmail_MouseHover_1(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter the Employee Email";
        }

        private void txtMob_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Enter the Mobile Number";
        }

    }
}
