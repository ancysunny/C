﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest2_Retest
{
    class CustomerDetails
    {
        int CustomerNo;
        public Customer[] customer;


        public CustomerDetails()
        {
            Console.Write("Enter the number of Customers: ");
            CustomerNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" ");
            customer = new Customer[CustomerNo];
        }

        public void ReadCustomerDetails()
        {
            for (int index = 0; index < CustomerNo; index++)
            {

                customer[index] = new Customer();
                Console.Write("Id :");
                customer[index].Id = Convert.ToInt32(Console.ReadLine());
                Console.Write("Name :");
                customer[index].Name = Console.ReadLine();


            }
        }

        public void DisplayCustomerDetails()
        {
            Console.WriteLine("----------CUSTOMER DETAILS----------");
            for (int index = 0; index < CustomerNo; index++)
            {

                Console.WriteLine("ID: " + customer[index].Id);
                Console.WriteLine("NAME: " + customer[index].Name);
                Console.WriteLine("USER TYPE: " + customer[index].UserType);
                Console.WriteLine(" ");
            }
        }


        public static void Main()
        {
            CustomerDetails cust = new CustomerDetails();
            cust.ReadCustomerDetails();
            cust.DisplayCustomerDetails();

            Console.ReadKey();

        }
    }

    class Customer
    {
        private int id;
        private string name;
        private int type;

        enum userType
        {
            retail = 0,
            wholesale = 1
        }

        public Customer()
        {
            Console.WriteLine(" ");
            Console.Write("Enter User Type(0/1) : ");
            type = Convert.ToInt32(Console.ReadLine());

        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        public Enum UserType
        {
            get
            {
                if (type == 0)
                {
                    return userType.retail;
                }
                else
                {
                    return userType.wholesale;
                }
            }

        }
    }
}
