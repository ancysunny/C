﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest2_Retest
{
    class EmployeeSalary
    {

        public static void Main()
        {
            Employee emp = new Employee();

            int option;
            int number = emp.ReadData();
            do
            {
                Console.WriteLine(" ");
                Console.WriteLine("*********************************");
                Console.WriteLine("1. READ THE DETAILS");
                Console.WriteLine("2. VIEW ALL");
                Console.WriteLine("3. DISPLAY THE PARTICULAR");
                Console.WriteLine("4. EXIT");
                Console.WriteLine("*********************************");
                Console.Write("Enter the choice : ");
                option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        for (int iteration = 0; iteration < number; iteration++)
                        {
                            Console.Write("Enter {0} Salary: ", iteration + 1);
                            emp[iteration] = Convert.ToInt32(Console.ReadLine());
                        }

                        break;

                    case 2:
                        for (int iteration = 0; iteration < number; iteration++)
                        {
                            Console.Write("\nSalary of Employee {0} : {1}", iteration + 1, emp[iteration]);
                        }
                        break;
                    case 3:
                        int indexer;
                        Console.Write("\nEnter the Index of the Employee : ");
                        indexer = Convert.ToInt16(Console.ReadLine());
                        Console.Write("Salary : " + emp[indexer]);
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid operation");
                        break;
                }
            } while (true);
        }
    }
    class Employee
    {
        public int noOfEmployees;
        public int[] salary;

        public int ReadData()
        {
            Console.Write("Enter the number of Employees: ");
            noOfEmployees = Convert.ToInt32(Console.ReadLine());
            salary = new int[noOfEmployees];

            return noOfEmployees;
        }
        public int this[int index]
        {
            get { return salary[index]; }
            set { salary[index] = value; }
        } 
    }
}
