﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest2_Retest
{
    class SortSalesArray
    {
        public static void Main()
        {
            SalesArray arrayobj = new SalesArray();
            arrayobj.ReadData();
            arrayobj.DisplayData();
            Console.ReadKey();
        }

    }
    class SalesArray
    {
        int numOfmonths;
        int[] sales;

        public void ReadData()
        {
            

            Console.Write("Enter the number of months: ");
            numOfmonths = Convert.ToInt32(Console.ReadLine());

            sales = new int[numOfmonths];

            

            for(int iteration =0;iteration<sales.Length;iteration++)
            {
                Console.Write("Enter {0} salary: ", iteration+1);
               
                try
                {
                    sales[iteration] = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("----------------Invalid Entry----------------\nEnter the valid: ");
                    sales[iteration] = Convert.ToInt32(Console.ReadLine());                                                             
                }
            }

            Console.WriteLine("----------------");
            Console.WriteLine("ARRAY");
            Console.WriteLine("----------------");
            foreach (int val in sales)
                {
                    Console.Write(" " + val);
                }
            Console.WriteLine(" ");

            }

            public  void DisplayData()
             {
                 for (int iteration1 = 0; iteration1 < sales.Length; iteration1++)
                 {
                     for (int iteration2 = iteration1 + 1; iteration2 < sales.Length; iteration2++)
                     {
                         if (sales[iteration1] > sales[iteration2])                                                                              
                         {
                             int temp = sales[iteration1];
                             sales[iteration1] = sales[iteration2];
                             sales[iteration2] = temp;
                         }
                     }
                 }
                 Console.WriteLine("----------------");
                 Console.WriteLine("SORTED ARRAY");
                 Console.WriteLine("----------------");
                 foreach (int val in sales)                                                                                 
                 {
                     Console.Write(" " + val);
                 }

             }
      }
}

