﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest2
{
    class SalesArray
    {
        public static void Main()
        {

            Sales sale1 = new Sales();
            sale1.ReadData();
            sale1.DisplayData();
            Console.ReadKey();
        }

        class Sales
        {
            int months;
            int[] sales;
             public void ReadData()
            {
                Console.Write("Enter the number of months : ");
                months = Convert.ToInt32(Console.ReadLine());                                                                  //no: of months read from console
                sales = new int[months];
                Console.WriteLine("Enter the sales amount:");
                for (int i = 0; i < sales.Length; i++)
                {

                    try
                    {
                        sales[i] = Convert.ToInt32(Console.ReadLine());
                    }
                    catch
                    {
                        Console.WriteLine("********Invalid Entry********\nEnter the valid: ");
                        sales[i] = Convert.ToInt32(Console.ReadLine());                                                              //exception handling
                    }
                }
                Console.WriteLine("----------------");
                Console.WriteLine("ARRAY");
                Console.WriteLine("----------------");
                foreach (int val in sales)
                {
                    Console.Write(" " + val);
                }
                Console.WriteLine(" ");

            }

            public  void DisplayData()
             {
                 for (int i = 0; i < sales.Length; i++)
                 {
                     for (int j = i + 1; j < sales.Length; j++)
                     {
                         if (sales[i] > sales[j])                                                                              //array sorting
                         {
                             int temp = sales[i];
                             sales[i] = sales[j];
                             sales[j] = temp;
                         }
                     }
                 }
                 Console.WriteLine("----------------");
                 Console.WriteLine("SORTED ARRAY");
                 Console.WriteLine("----------------");
                 foreach (int val in sales)                                                                                 //displaying by foreach
                 {
                     Console.Write(" " + val);
                 }

             }
        }

    }
    
}
    
   