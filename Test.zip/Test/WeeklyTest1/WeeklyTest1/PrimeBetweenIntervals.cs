﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class PrimeBetweenIntervals
    {
        int a, b;
        bool flag = true;

        public void ReadData()
        {
            Console.Write("Enter the 1st Interval: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the 2nd Interval: ");
            b = Convert.ToInt32(Console.ReadLine());
        }

        public Boolean CheckPrime(int n)
        {
            int i;
            bool flag = true;
            for (i = 2; i < n - 1; i++)
            {
                if (n % i == 0)
                {
                    flag = false;
                    break;
                }
            }
            return flag;
        }

        public void CheckInterval()
        {
            Console.WriteLine("The prime numbers between {0} and {1} are: ", a, b);
            for (int i = a; i <= b; i++)
            {
                if (CheckPrime(i))
                {
                    Console.WriteLine(i);
                }

            }
        }
        public static void Main()
        {
            PrimeBetweenIntervals bet = new PrimeBetweenIntervals();
            bet.ReadData();
            bet.CheckInterval();

            Console.ReadKey();
        }

       

    }
}
