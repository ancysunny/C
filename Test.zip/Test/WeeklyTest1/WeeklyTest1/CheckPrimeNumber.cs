﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class CheckPrimeNumber
    {
        int num;
        bool flag = true;

        public void ReadData()
        {
            Console.Write("Enter the number: ");
            num = Convert.ToInt32(Console.ReadLine());
        }

        public void CheckPrime()
        {
            int n = num;
            
            for (int i = 2; i <= n-1; i++)
            {

                if (n % i == 0)
                {
                    flag = false;
                    break;                  
                }             
            }
        }
        public void DisplayData()
        {
            if(flag)
            {
                Console.WriteLine("PRIME NUMBER");
            }
            else
            {
                Console.WriteLine("Not PRIME NUMBER");
            }
        }

        public static void Main()
        {
            CheckPrimeNumber check = new CheckPrimeNumber();
            check.ReadData();
            check.CheckPrime();
            check.DisplayData();

            Console.ReadKey();
        }
    }
}
