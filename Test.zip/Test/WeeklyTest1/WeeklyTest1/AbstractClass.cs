﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class AbstractClass
    {
        
        public static void Main()
        {

            Console.WriteLine("First Person");
            Console.WriteLine("------------------");
            SBAccount sb1 = new SBAccount();
            sb1.ReadData();
            sb1.CalculateInterest();
            Console.WriteLine(" ");
            sb1.DisplayData();          
            Console.WriteLine(" ");

            Console.WriteLine("Second Person");
            Console.WriteLine("------------------");
            SBAccount sb2 = new SBAccount();
            sb2.ReadData();
            sb2.CalculateInterest();
            Console.WriteLine(" ");
            sb2.DisplayData();
                      
            Console.ReadKey();

        }
    }

    abstract class Account
    {

        public readonly int AccountId;
        static int id = 111;
        public Account()
        {
            AccountId = id;
            id++;
        }
        public abstract void CalculateInterest();


    }

    class SBAccount : Account
    {

        int P,R,T;
        string name;
        int interest;
        
        public void ReadData()
        {
           
         
            Console.Write("Name: ");
            name = Convert.ToString(Console.ReadLine());
            Console.Write("Amount: ");
            P = Convert.ToInt32(Console.ReadLine());
            Console.Write("Rate of Interest: ");
            R = Convert.ToInt32(Console.ReadLine());
            Console.Write("Years: ");
            T = Convert.ToInt32(Console.ReadLine());
        }
        public override void CalculateInterest()
        {            
            interest = P * (1 +(R*T));           
        }

        public void DisplayData()
        {

            Console.WriteLine("Name: "+name);
            Console.WriteLine("AccountID: "+AccountId);
            Console.WriteLine("Interest: " +interest);
           
            
        }
    }
}
