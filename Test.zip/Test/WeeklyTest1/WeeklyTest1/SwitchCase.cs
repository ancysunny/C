﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class SwitchCase
    {
        
        public static void Main()
        {
            int choice;
            do
            {
                Console.WriteLine("---------------------------");
                Console.WriteLine("a. PRIME OR NOT");
                Console.WriteLine("b. PRIME NUMBERS BETWEEN 2 INTERVALS");
                Console.WriteLine("c. GENERATE N PRIME NUMBERS");
                Console.WriteLine("d. Exit");
                Console.WriteLine("---------------------------");
                Console.Write("Enter the choice:");
                choice = Convert.ToInt32(Console.ReadLine());





                switch (choice)
                {

                    case 1:
                        CheckPrimeNumber check = new CheckPrimeNumber();
                        check.ReadData();
                        check.CheckPrime();
                        check.DisplayData();

                        break;

                    case 2:
                        PrimeBetweenIntervals bet = new PrimeBetweenIntervals();
                        bet.ReadData();
                        bet.CheckInterval();

                        break;


                    case 3:
                        GeneratePrime gen = new GeneratePrime();
                        gen.ReadData();
                        gen.GenPrime();

                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("wrong choice");
                        break;


                }
            } while (true);
        }

    }
}
