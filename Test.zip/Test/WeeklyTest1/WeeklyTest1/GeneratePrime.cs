﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class GeneratePrime
    {
        int limit,count=0;

        public void ReadData()
        {
            Console.Write("Enter the limit: ");
            limit = Convert.ToInt32(Console.ReadLine());
        }

        public Boolean CheckPrime(int n)
        {
            int i;
            bool flag = true;
            for (i = 2; i < n - 1; i++)
            {
                if (n % i == 0)
                {
                    flag = false;
                    break;
                }
            }
            return flag;


        }

       
        public void GenPrime()
        {
            int p=2;
            int n1 = limit;
            Console.WriteLine("The prime numbers are : " );

            while(count<n1)
            {
                if (CheckPrime(p))
                {                   
                        Console.WriteLine(p);
                        count++;
                }
                p++;

            }
        }
       
        public static void Main()
        {
            GeneratePrime gen = new GeneratePrime();
            gen.ReadData();
            gen.GenPrime();
            Console.ReadKey();
        }

        
    }
}
