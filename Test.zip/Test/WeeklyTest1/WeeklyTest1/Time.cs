﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class Time
    {
        int hr, min,sec;

        
        public void DisplayTime()
        {
            Console.WriteLine("{0}:{1}:{2}", hr, min,sec);

        }
        public void ReadTime()
        {
            Console.Write("Hours :");
            hr = Convert.ToInt32(Console.ReadLine());
            Console.Write("Minutes :");
            min = Convert.ToInt32(Console.ReadLine());
            Console.Write("Seconds :");
            sec = Convert.ToInt32(Console.ReadLine());

        }

        public static Time operator +(Time T1, Time T2)
        {
            Time t = new Time();
            t.hr = T1.hr + T2.hr;
            t.sec = T1.sec + T2.sec;
            if (t.sec >= 60)
            {
                t.min++;
                t.sec %= 60;
            }
            t.min += T1.min + T2.min;
            if (t.min >= 60)
            {
                t.hr++;
                t.min %= 60;
            }
            
            return t;
        }
       
        
        public static void Main()
        {
            Time t1 = new Time();
            Time t2 = new Time();
            Time t3;
            
            Console.WriteLine("Enter the value of Time 1 ");
            t1.ReadTime();
            Console.WriteLine("Enter the value of Time 2 ");
            t2.ReadTime();

            t3 = t1 + t2;
            t3.DisplayTime();

            Console.ReadKey();
        }

        
       
    }
}
