﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WeeklyTest3
{

    class CreateMultiThread
    {
        public static void Main()
        {

            Table t = new Table();
            Console.WriteLine("********************************");
            GenerateTable gt1 = new GenerateTable(5);
            Thread th1 = new Thread(gt1.ReadData);
            th1.Start();

            Console.WriteLine("********************************");
            GenerateTable gt2 = new GenerateTable(10);
            Thread th2 = new Thread(gt2.ReadData);
            th2.Start();

            Console.WriteLine("********************************");
            GenerateTable gt3 = new GenerateTable(15);
            Thread th3 = new Thread(gt3.ReadData);
            th3.Start();

            Console.ReadKey();
        }
    }
        
    class Table
    {

        public void CreateTable(int n)
        {
            lock(this)
            {
               for (int iteration = 1; iteration <= 10; iteration++)
               {
                  Console.WriteLine("{0} * {1} = {2}", iteration, n, (iteration * n));
               }           
            }           
        }
    }

    class GenerateTable
    {
        Table t;
        private int n;

        public GenerateTable(int target)
        {
            n = target;
        }
        public void  ReadData()
        {
                t = new Table();
                t.CreateTable(n);
        }

    }
}
    
       


