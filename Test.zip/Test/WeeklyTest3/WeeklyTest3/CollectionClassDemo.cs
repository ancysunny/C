﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest3
{
    class CollectionClassDemo
    {

        

        public static void Main()
        {
             Hashtable AddressBook = null;

            int choice;

            do
            {
                Console.WriteLine();
                Console.WriteLine("**************************");
                Console.WriteLine("1. ADD CONTACT");
                Console.WriteLine("2. SEARCH CONTACT");
                Console.WriteLine("3. DELETE CONTACT");
                Console.WriteLine("4. VIEW ALL");
                Console.WriteLine("5. EXIT");
                Console.WriteLine("**************************");
                Console.Write("Enter the option (1-5):");
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                switch(choice)
                {
                    case 1:

                        if(AddressBook==null)
                        {
                            AddressBook = new Hashtable();
                            AddressBook.Add(101, new Contact { ID = 100, Name = "Saju", PhNo = 2345678 });
                            AddressBook.Add(102, new Contact { ID = 102, Name = "Appu", PhNo = 2678453 });
                            AddressBook.Add(103, new Contact { ID = 103, Name = "Bini", PhNo = 2854368 });
                            AddressBook.Add(104, new Contact { ID = 104, Name = "Mary", PhNo = 2683249 });
                            AddressBook.Add(105, new Contact { ID = 105, Name = "Rsil", PhNo = 2680444 });
                        }
                        else
                        {
                            Console.WriteLine("No contact is available\n");
                        }
                        Console.WriteLine("ADDED TO ADDRESS BOOK");
                        
                        break;

                    case 2:
                        Console.Write("Enter the contact to be searched:");
                        int search = Convert.ToInt32(Console.ReadLine());0
                        Console.WriteLine();
                        bool flag = false;
                        if (AddressBook != null)
                        {
                            ICollection key = AddressBook.Keys;
                            foreach (int k in key)
                            {
                                if(k == search)
                                {
                                    flag = true;
                                }                               
                            }
                            if(flag)
                            {
                                Console.WriteLine("Contact Found");

                            }
                            else
                            {
                                Console.WriteLine("Contact Unfound");
                            }
                        }
                        break;

                    case 3:
                        Console.Write("Enter the contact to be deleted:");
                        int delete = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine();
                        if (AddressBook != null)
                        {
                            ICollection key = AddressBook.Keys;
                            foreach (int k in key)
                            {
                                
                                if (k == delete)
                                {
                                    AddressBook.Remove(k);
                                    Console.WriteLine("Contact Deleted");
                                }
                            }
                            
                        }
                        break;

                    case 4:
                        Console.WriteLine("    ADDRESS BOOK");
                        Console.WriteLine("   --------------\n");
                        Console.WriteLine("  ID  |  Name  | Phone Number \n");
                        Contact contact;

                        if (AddressBook != null)
                        {
                            ICollection key = AddressBook.Keys;
                            foreach(int k in key)
                            {
                                contact = ((Contact)AddressBook[k]);
                                Console.WriteLine("  {0}    {1}     {2} ", contact.ID, contact.Name, contact.PhNo);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No contact is available\n");
                        }
                        break;

                    case 5:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Entry");
                        break;
                }
            } while (true);



             
        }
       
    }






















     class Contact
    {
        public int ID{get;set;}
        public string Name { get; set; }
        public int PhNo { get; set; }
    }
}
