﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest3
{
    public delegate bool IsTopperDelegate(Student student);
    class CallbackDelegate
    {
            
        public static void Main()
        {

            List<Student> studentList = new List<Student>();

            studentList.Add(new Student { ID = 111, Name = "Anu", Marks = 48, Grade = 'A' });
            studentList.Add(new Student { ID = 112, Name = "Appu", Marks = 23, Grade = 'B' });
            studentList.Add(new Student { ID = 113, Name = "Ammu", Marks = 45, Grade = 'A' });
            studentList.Add(new Student { ID = 114, Name = "Aashu", Marks = 42, Grade = 'A' });
            studentList.Add(new Student { ID = 115, Name = "Arjun", Marks = 34, Grade = 'B' });

            IsTopperDelegate topperdelegate = new IsTopperDelegate(IsTopper);
            Student.GetTopperList(studentList, topperdelegate);

            Console.ReadKey();


        }

        public static bool IsTopper(Student student)
        {
            bool topper = false;

            if (student.Marks >= 45 && student.Grade == 'A')
            {
                topper = true;
            }
            return topper;             
        }
    }


     public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Marks { get; set; }
        public char Grade { get; set; }

        public static void GetTopperList(List<Student> students, IsTopperDelegate topperdelegate)
        {
            Console.WriteLine("List of students eligible for promotion");
            Console.WriteLine("***************************************");
            Console.WriteLine();
            Console.WriteLine("Student ID| Student Name | Student Mark | Student Grade");
            Console.WriteLine();
            foreach(Student student in students)
            {
                if(topperdelegate(student))
                {
                    Console.WriteLine();
                    Console.WriteLine("    {0}         {1}          {2}            {3}      ", student.ID, student.Name, student.Marks, student.Grade);
                } 
            }

        }

    }
}
