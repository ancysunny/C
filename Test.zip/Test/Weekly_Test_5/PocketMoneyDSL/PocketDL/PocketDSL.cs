﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using PocketMoneyDTO.PocketDTO;
using PocketMoneyDSL.DBHelper;

namespace PocketMoneyDSL.PocketDL
{
    public class PocketDSL
    {
        public static int PocketMoneyInsert(PocketMoney pocketMoney)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "insert into transaction_table (transaction_id,transaction_item,transaction_type,transaction_amount,transaction_date) values (";

                sql = sql + "'" + pocketMoney.TransactionId + "',";
                sql = sql + "'" + pocketMoney.TransactionItem + "',";
                sql = sql + "'" + pocketMoney.TransactionType + "',";
                sql = sql + "'" + pocketMoney.TransactionAmount + "',";
                sql = sql + "'" + pocketMoney.TransactionDate + "')";

                con = DbHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();

            }
            catch(Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:PocketMoneyInsert" + ex.Message.ToString());
            }
             finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



        public static int PocketMoneyDelete(string transaction_id)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "delete from transaction_table where transaction_id='" + transaction_id + "'";


                con = DbHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:PocketMoneyDelete" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



        public static int PocketMoneyUpdate(PocketMoney pocketMoney)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "update transaction_table set ";

                sql = sql + "transaction_item = '" + pocketMoney.TransactionItem + "',";
                sql = sql + "transaction_type = '" + pocketMoney.TransactionType + "',";
                sql = sql + "transaction_amount = '" + pocketMoney.TransactionAmount + "',";
                sql = sql + "transaction_date = '" + pocketMoney.TransactionDate + "'";
                sql = sql + "where transaction_id ='" + pocketMoney.TransactionId + "'";

                con = DbHelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:PocketMoneyUpdate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }


        public static DataSet GetTransactionIds()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select transaction_id from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionIds" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }


        public static DataSet GetTransaction()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select * from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransaction" + ex.Message.ToString()); 
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }


        public static PocketMoney GetTransactionById(string transaction_id)
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            PocketMoney pocketMoney = null;
            try
            {

                sql = "select * from transaction_table where transaction_id='" + transaction_id + "'";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
                object[] Data = null;
                if (dsTransaction.Tables[0].Rows.Count > 0)
                {
                    Data = dsTransaction.Tables[0].Rows[0].ItemArray;
                    pocketMoney = new PocketMoney();
                    pocketMoney.TransactionId = Data[0].ToString();
                    pocketMoney.TransactionItem = Data[1].ToString();
                    pocketMoney.TransactionType = Data[2].ToString();
                    pocketMoney.TransactionAmount = Data[3].ToString();
                    pocketMoney.TransactionDate = Data[4].ToString();
                   
                }
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionById" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return pocketMoney;
        }



        public static DataSet GetTransactionItems()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select transaction_item from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionItems" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }



        public static DataSet GetTransaction1()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select * from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransaction1" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }
        public static DataSet GetTransactionByItem(string transaction_item)
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            PocketMoney pocketMoney = null;
            try
            {

                sql = "select * from transaction_table where transaction_item='" + transaction_item + "'";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
               
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionByItem" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }



        public static DataSet GetTransactionDate()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select transaction_date from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionDate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }



        public static DataSet GetTransaction2()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            try
            {

                sql = "select * from transaction_table";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransaction2" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }
        public static DataSet GetTransactionByDate(string transaction_date)
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsTransaction = null;
            PocketMoney pocketMoney = null;
            try
            {

                sql = "select * from transaction_table where transaction_date='" + transaction_date + "'";

                con = DbHelper.GetConnection();

                con.Open();

                dsTransaction = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsTransaction);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketDSL.cs:GetTransactionByDate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsTransaction;
        }
           
    }
}

































 