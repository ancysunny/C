﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using PocketMoneyDSL.PocketDL;
using PocketMoneyDTO.PocketDTO;

namespace PocketMoneyBLL.PocketBL
{
    public class PocketBLL
    {

        public static int PocketMoneyInsert(PocketMoney pocketMoney)
        {
            int output = 0;
            
            try
            {

                output = PocketDSL.PocketMoneyInsert(pocketMoney);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:PocketMoneyInsert" + ex.Message.ToString());
            }
           
            return output;
        }



        public static int PocketMoneyDelete(string transaction_id)
        {
            int output = 0;
           
            try
            {

                output = PocketDSL.PocketMoneyDelete(transaction_id);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:PocketMoneyDelete" + ex.Message.ToString());
            }
           
            return output;
        }



        public static int PocketMoneyUpdate(PocketMoney pocketMoney)
        {
            int output = 0;
            
            try
            {

                output = PocketDSL.PocketMoneyUpdate(pocketMoney);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:PocketMoneyUpdate" + ex.Message.ToString());
            }
            
            return output;
        }


        public static DataSet GetTransactionIds()
        {
          
            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransactionIds();
                
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionIds" + ex.Message.ToString());
            }
            
            return dsTransaction;
        }


        public static DataSet GetTransaction()
        {
           
            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransaction();
                
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransaction" + ex.Message.ToString());
            }
           
            return dsTransaction;
        }


        public static PocketMoney GetTransactionById(string transaction_id)
        {
                      
            PocketMoney pocketMoney = null;
            try
            {
                pocketMoney = PocketDSL.GetTransactionById(transaction_id);
                
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionById" + ex.Message.ToString());
            }
            
            return pocketMoney;
        }


        public static DataSet GetTransactionItems()
        {

            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransactionItems();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionItems" + ex.Message.ToString());
            }

            return dsTransaction;
        }


        public static DataSet GetTransaction1()
        {

            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransaction1();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransaction1" + ex.Message.ToString());
            }

            return dsTransaction;
        }

        public static DataSet GetTransactionByItem(string transaction_item)
        {

            DataSet pocketMoney = null;
            try
            {
                pocketMoney = PocketDSL.GetTransactionByItem(transaction_item);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionByItem" + ex.Message.ToString());
            }

            return pocketMoney;
        }



        public static DataSet GetTransactionDate()
        {

            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransactionDate();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionDate" + ex.Message.ToString());
            }

            return dsTransaction;
        }


        public static DataSet GetTransaction2()
        {

            DataSet dsTransaction = null;

            try
            {

                dsTransaction = PocketDSL.GetTransaction2();

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransaction2" + ex.Message.ToString());
            }

            return dsTransaction;
        }

        public static DataSet GetTransactionByDate(string transaction_date)
        {

            DataSet pocketMoney = null;
            try
            {
                pocketMoney = PocketDSL.GetTransactionByDate(transaction_date);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:PocketBLL.cs:GetTransactionByDate" + ex.Message.ToString());
            }

            return pocketMoney;
        }
    }
}
