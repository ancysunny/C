﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PocketMoneyDTO.PocketDTO
{
    public class PocketMoney
    {
        private string  transaction_id;

        public string  TransactionId
        {
            get { return transaction_id; }
            set { transaction_id = value; }
        }

        private string  transaction_item;

        public string  TransactionItem
        {
            get { return transaction_item; }
            set { transaction_item = value; }
        }

        private string  transaction_type;

        public string  TransactionType
        {
            get { return transaction_type; }
            set { transaction_type = value; }
        }

        private string  transaction_amount;

        public string  TransactionAmount
        {
            get { return transaction_amount; }
            set { transaction_amount = value; }
        }

        private string  transaction_date;

        public string  TransactionDate
        {
            get { return transaction_date; }
            set { transaction_date = value; }
        }
        
        
    }
}
