﻿namespace PocketMoneyPL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblHead = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblItem = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.cmbItems = new System.Windows.Forms.ComboBox();
            this.rbCredit = new System.Windows.Forms.RadioButton();
            this.rbDebit = new System.Windows.Forms.RadioButton();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.dgvPocketMoney = new System.Windows.Forms.DataGridView();
            this.pocket_moneyDataSet = new PocketMoneyPL.pocket_moneyDataSet();
            this.transactiontableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.transaction_tableTableAdapter = new PocketMoneyPL.pocket_moneyDataSetTableAdapters.transaction_tableTableAdapter();
            this.transactionidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionitemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactiontypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionamountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactiondateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSearchItem = new System.Windows.Forms.Label();
            this.lblSearchDate = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.cmbSearchDate = new System.Windows.Forms.ComboBox();
            this.btnSAVE = new System.Windows.Forms.Button();
            this.btnUPDATE = new System.Windows.Forms.Button();
            this.btnCLEAR = new System.Windows.Forms.Button();
            this.btnDELETE = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.ep1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.cmbID = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPocketMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pocket_moneyDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.transactiontableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ep1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblHead
            // 
            this.lblHead.AutoSize = true;
            this.lblHead.Font = new System.Drawing.Font("Castellar", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHead.ForeColor = System.Drawing.Color.Maroon;
            this.lblHead.Location = new System.Drawing.Point(292, 9);
            this.lblHead.Name = "lblHead";
            this.lblHead.Size = new System.Drawing.Size(220, 25);
            this.lblHead.TabIndex = 0;
            this.lblHead.Text = "Pocket Money ";
            this.lblHead.Click += new System.EventHandler(this.lblHead_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(132, 75);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(118, 19);
            this.lblID.TabIndex = 1;
            this.lblID.Text = "Transaction ID";
            // 
            // lblItem
            // 
            this.lblItem.AutoSize = true;
            this.lblItem.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem.Location = new System.Drawing.Point(132, 134);
            this.lblItem.Name = "lblItem";
            this.lblItem.Size = new System.Drawing.Size(136, 19);
            this.lblItem.TabIndex = 2;
            this.lblItem.Text = "Transaction Item";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.Location = new System.Drawing.Point(132, 193);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(138, 19);
            this.lblType.TabIndex = 3;
            this.lblType.Text = "Transaction Type";
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.Location = new System.Drawing.Point(132, 252);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(163, 19);
            this.lblAmount.TabIndex = 4;
            this.lblAmount.Text = "Transaction Amount";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(132, 311);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(137, 19);
            this.lblDate.TabIndex = 5;
            this.lblDate.Text = "Transaction Date";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(440, 74);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(283, 20);
            this.txtID.TabIndex = 6;
            this.txtID.Validating += new System.ComponentModel.CancelEventHandler(this.txtID_Validating);
            // 
            // cmbItems
            // 
            this.cmbItems.Font = new System.Drawing.Font("Lucida Sans Typewriter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbItems.FormattingEnabled = true;
            this.cmbItems.Items.AddRange(new object[] {
            "GAS",
            "VEGETABLES",
            "FRUITS",
            "SNACKS",
            "DRESS"});
            this.cmbItems.Location = new System.Drawing.Point(440, 128);
            this.cmbItems.Name = "cmbItems";
            this.cmbItems.Size = new System.Drawing.Size(283, 25);
            this.cmbItems.TabIndex = 7;
            this.cmbItems.Text = "      - - - Select - - -";
            this.cmbItems.Validating += new System.ComponentModel.CancelEventHandler(this.cmbItems_Validating);
            // 
            // rbCredit
            // 
            this.rbCredit.AutoSize = true;
            this.rbCredit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rbCredit.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCredit.Location = new System.Drawing.Point(461, 187);
            this.rbCredit.Name = "rbCredit";
            this.rbCredit.Size = new System.Drawing.Size(73, 25);
            this.rbCredit.TabIndex = 8;
            this.rbCredit.Text = "Credit";
            this.rbCredit.UseVisualStyleBackColor = false;
            // 
            // rbDebit
            // 
            this.rbDebit.AutoSize = true;
            this.rbDebit.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rbDebit.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDebit.Location = new System.Drawing.Point(620, 189);
            this.rbDebit.Name = "rbDebit";
            this.rbDebit.Size = new System.Drawing.Size(68, 25);
            this.rbDebit.TabIndex = 9;
            this.rbDebit.Text = "Debit";
            this.rbDebit.UseVisualStyleBackColor = false;
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(440, 251);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(283, 20);
            this.txtAmount.TabIndex = 10;
            this.txtAmount.Validating += new System.ComponentModel.CancelEventHandler(this.txtAmount_Validating);
            // 
            // dtpTime
            // 
            this.dtpTime.Location = new System.Drawing.Point(440, 309);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.Size = new System.Drawing.Size(283, 20);
            this.dtpTime.TabIndex = 11;
            this.dtpTime.Validating += new System.ComponentModel.CancelEventHandler(this.dtpTime_Validating);
            // 
            // dgvPocketMoney
            // 
            this.dgvPocketMoney.AutoGenerateColumns = false;
            this.dgvPocketMoney.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvPocketMoney.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPocketMoney.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.transactionidDataGridViewTextBoxColumn,
            this.transactionitemDataGridViewTextBoxColumn,
            this.transactiontypeDataGridViewTextBoxColumn,
            this.transactionamountDataGridViewTextBoxColumn,
            this.transactiondateDataGridViewTextBoxColumn});
            this.dgvPocketMoney.DataSource = this.transactiontableBindingSource;
            this.dgvPocketMoney.Location = new System.Drawing.Point(179, 457);
            this.dgvPocketMoney.Name = "dgvPocketMoney";
            this.dgvPocketMoney.Size = new System.Drawing.Size(544, 169);
            this.dgvPocketMoney.TabIndex = 12;
            // 
            // pocket_moneyDataSet
            // 
            this.pocket_moneyDataSet.DataSetName = "pocket_moneyDataSet";
            this.pocket_moneyDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // transactiontableBindingSource
            // 
            this.transactiontableBindingSource.DataMember = "transaction_table";
            this.transactiontableBindingSource.DataSource = this.pocket_moneyDataSet;
            // 
            // transaction_tableTableAdapter
            // 
            this.transaction_tableTableAdapter.ClearBeforeFill = true;
            // 
            // transactionidDataGridViewTextBoxColumn
            // 
            this.transactionidDataGridViewTextBoxColumn.DataPropertyName = "transaction_id";
            this.transactionidDataGridViewTextBoxColumn.HeaderText = "transaction_id";
            this.transactionidDataGridViewTextBoxColumn.Name = "transactionidDataGridViewTextBoxColumn";
            // 
            // transactionitemDataGridViewTextBoxColumn
            // 
            this.transactionitemDataGridViewTextBoxColumn.DataPropertyName = "transaction_item";
            this.transactionitemDataGridViewTextBoxColumn.HeaderText = "transaction_item";
            this.transactionitemDataGridViewTextBoxColumn.Name = "transactionitemDataGridViewTextBoxColumn";
            // 
            // transactiontypeDataGridViewTextBoxColumn
            // 
            this.transactiontypeDataGridViewTextBoxColumn.DataPropertyName = "transaction_type";
            this.transactiontypeDataGridViewTextBoxColumn.HeaderText = "transaction_type";
            this.transactiontypeDataGridViewTextBoxColumn.Name = "transactiontypeDataGridViewTextBoxColumn";
            // 
            // transactionamountDataGridViewTextBoxColumn
            // 
            this.transactionamountDataGridViewTextBoxColumn.DataPropertyName = "transaction_amount";
            this.transactionamountDataGridViewTextBoxColumn.HeaderText = "transaction_amount";
            this.transactionamountDataGridViewTextBoxColumn.Name = "transactionamountDataGridViewTextBoxColumn";
            // 
            // transactiondateDataGridViewTextBoxColumn
            // 
            this.transactiondateDataGridViewTextBoxColumn.DataPropertyName = "transaction_date";
            this.transactiondateDataGridViewTextBoxColumn.HeaderText = "transaction_date";
            this.transactiondateDataGridViewTextBoxColumn.Name = "transactiondateDataGridViewTextBoxColumn";
            // 
            // lblSearchItem
            // 
            this.lblSearchItem.AutoSize = true;
            this.lblSearchItem.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchItem.Location = new System.Drawing.Point(68, 396);
            this.lblSearchItem.Name = "lblSearchItem";
            this.lblSearchItem.Size = new System.Drawing.Size(99, 19);
            this.lblSearchItem.TabIndex = 13;
            this.lblSearchItem.Text = "Search Item";
            // 
            // lblSearchDate
            // 
            this.lblSearchDate.AutoSize = true;
            this.lblSearchDate.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchDate.Location = new System.Drawing.Point(511, 396);
            this.lblSearchDate.Name = "lblSearchDate";
            this.lblSearchDate.Size = new System.Drawing.Size(100, 19);
            this.lblSearchDate.TabIndex = 14;
            this.lblSearchDate.Text = "Search Date";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(183, 394);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(185, 25);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.Text = " - - Select - -";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cmbSearchDate
            // 
            this.cmbSearchDate.Font = new System.Drawing.Font("Lucida Sans Typewriter", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearchDate.FormattingEnabled = true;
            this.cmbSearchDate.Location = new System.Drawing.Point(629, 394);
            this.cmbSearchDate.Name = "cmbSearchDate";
            this.cmbSearchDate.Size = new System.Drawing.Size(178, 25);
            this.cmbSearchDate.TabIndex = 16;
            this.cmbSearchDate.Text = " - - Select - - ";
            this.cmbSearchDate.SelectedIndexChanged += new System.EventHandler(this.cmbSearchDate_SelectedIndexChanged);
            // 
            // btnSAVE
            // 
            this.btnSAVE.BackColor = System.Drawing.Color.Green;
            this.btnSAVE.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSAVE.Location = new System.Drawing.Point(784, 51);
            this.btnSAVE.Name = "btnSAVE";
            this.btnSAVE.Size = new System.Drawing.Size(94, 48);
            this.btnSAVE.TabIndex = 17;
            this.btnSAVE.Text = "SAVE";
            this.btnSAVE.UseVisualStyleBackColor = false;
            this.btnSAVE.Click += new System.EventHandler(this.btnSAVE_Click);
            // 
            // btnUPDATE
            // 
            this.btnUPDATE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnUPDATE.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUPDATE.Location = new System.Drawing.Point(784, 223);
            this.btnUPDATE.Name = "btnUPDATE";
            this.btnUPDATE.Size = new System.Drawing.Size(94, 48);
            this.btnUPDATE.TabIndex = 19;
            this.btnUPDATE.Text = "UPDATE";
            this.btnUPDATE.UseVisualStyleBackColor = false;
            this.btnUPDATE.Click += new System.EventHandler(this.btnUPDATE_Click);
            // 
            // btnCLEAR
            // 
            this.btnCLEAR.BackColor = System.Drawing.Color.Violet;
            this.btnCLEAR.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCLEAR.Location = new System.Drawing.Point(784, 309);
            this.btnCLEAR.Name = "btnCLEAR";
            this.btnCLEAR.Size = new System.Drawing.Size(94, 48);
            this.btnCLEAR.TabIndex = 20;
            this.btnCLEAR.Text = "CLEAR";
            this.btnCLEAR.UseVisualStyleBackColor = false;
            this.btnCLEAR.Click += new System.EventHandler(this.btnCLEAR_Click);
            // 
            // btnDELETE
            // 
            this.btnDELETE.BackColor = System.Drawing.Color.Red;
            this.btnDELETE.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDELETE.Location = new System.Drawing.Point(784, 137);
            this.btnDELETE.Name = "btnDELETE";
            this.btnDELETE.Size = new System.Drawing.Size(94, 48);
            this.btnDELETE.TabIndex = 21;
            this.btnDELETE.Text = "DELETE";
            this.btnDELETE.UseVisualStyleBackColor = false;
            this.btnDELETE.Click += new System.EventHandler(this.btnDELETE_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblMessage.Location = new System.Drawing.Point(355, 51);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 22);
            this.lblMessage.TabIndex = 22;
            // 
            // ep1
            // 
            this.ep1.ContainerControl = this;
            // 
            // cmbID
            // 
            this.cmbID.FormattingEnabled = true;
            this.cmbID.Location = new System.Drawing.Point(602, 30);
            this.cmbID.Name = "cmbID";
            this.cmbID.Size = new System.Drawing.Size(121, 21);
            this.cmbID.TabIndex = 23;
            this.cmbID.SelectedIndexChanged += new System.EventHandler(this.cmbID_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(904, 638);
            this.Controls.Add(this.cmbID);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnDELETE);
            this.Controls.Add(this.btnCLEAR);
            this.Controls.Add(this.btnUPDATE);
            this.Controls.Add(this.btnSAVE);
            this.Controls.Add(this.cmbSearchDate);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lblSearchDate);
            this.Controls.Add(this.lblSearchItem);
            this.Controls.Add(this.dgvPocketMoney);
            this.Controls.Add(this.dtpTime);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.rbDebit);
            this.Controls.Add(this.rbCredit);
            this.Controls.Add(this.cmbItems);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblItem);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblHead);
            this.Name = "Form1";
            this.Text = "Pocket Money";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPocketMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pocket_moneyDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.transactiontableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ep1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblHead;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblItem;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.ComboBox cmbItems;
        private System.Windows.Forms.RadioButton rbCredit;
        private System.Windows.Forms.RadioButton rbDebit;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.DataGridView dgvPocketMoney;
        private pocket_moneyDataSet pocket_moneyDataSet;
        private System.Windows.Forms.BindingSource transactiontableBindingSource;
        private pocket_moneyDataSetTableAdapters.transaction_tableTableAdapter transaction_tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionitemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactiontypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactiondateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblSearchItem;
        private System.Windows.Forms.Label lblSearchDate;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox cmbSearchDate;
        private System.Windows.Forms.Button btnSAVE;
        private System.Windows.Forms.Button btnUPDATE;
        private System.Windows.Forms.Button btnCLEAR;
        private System.Windows.Forms.Button btnDELETE;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ErrorProvider ep1;
        private System.Windows.Forms.ComboBox cmbID;
    }
}

