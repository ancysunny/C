﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PocketMoneyBLL.PocketBL;
using PocketMoneyDTO.PocketDTO;

namespace PocketMoneyPL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pocket_moneyDataSet.transaction_table' table. You can move, or remove it, as needed.
            this.transaction_tableTableAdapter.Fill(this.pocket_moneyDataSet.transaction_table);
            LoadTransactionIds();
            LoadTransaction();
            LoadTransactionItems();
            LoadTransaction1();
            LoadTransaction2();
            LoadTransactionDates();

        }

        private void lblHead_Click(object sender, EventArgs e)
        {

        }

        private void txtID_Validating(object sender, CancelEventArgs e)
        {
            if (txtID.Text == string.Empty)
            {
                ep1.SetError(txtID, "Transaction ID is required !");
            }
            else
            {
                ep1.SetError(txtID, string.Empty);
            }
        }

        private void cmbItems_Validating(object sender, CancelEventArgs e)
        {
            if (cmbItems.Text == string.Empty)
            {
                ep1.SetError(cmbItems, "Select an item");
            }
            else
            {
                ep1.SetError(cmbItems, string.Empty);
            }
        }

        private void txtAmount_Validating(object sender, CancelEventArgs e)
        {
            if (txtAmount.Text == string.Empty)
            {
                ep1.SetError(txtAmount, "Enter the amount");
            }
            else
            {
                ep1.SetError(txtAmount, string.Empty);
            }
        }

        private void dtpTime_Validating(object sender, CancelEventArgs e)
        {
            if (dtpTime.Text == string.Empty)
            {
                ep1.SetError(dtpTime, "Enter the date");
            }
            else
            {
                ep1.SetError(dtpTime, string.Empty);
            }
        }

        private void btnSAVE_Click(object sender, EventArgs e)
        {
            int output = 0;
            PocketMoney pocketMoney = null;
            try
            {
                if (txtID.Text == string.Empty || cmbItems.Text == string.Empty || dtpTime.Text == string.Empty)
                {
                    lblMessage.Text = "ENTER DETAILS";
                    foreach (Control control in this.Controls)
                    {
                        control.Focus();

                        if (!Validate())
                        {
                            DialogResult = DialogResult.None;
                            return;
                        }
                    }

                }

                else
                {
                    pocketMoney = new PocketMoney();


                    pocketMoney.TransactionId = txtID.Text;

                    if (cmbItems.SelectedIndex == -1)
                    {
                        lblMessage.Text = "SELECT ITEM";
                        return;
                    }
                    else
                    {
                        pocketMoney.TransactionItem = cmbItems.Text;
                    }

                    if (!rbCredit.Checked && !rbDebit.Checked)
                    {
                        lblMessage.Text = "SELECT TYPE";
                        return;
                    }

                    else if (rbCredit.Checked)
                    {
                        pocketMoney.TransactionType = "Credit";
                    }
                    else
                    {
                        pocketMoney.TransactionType = "Debit";
                    }

                    pocketMoney.TransactionAmount = txtAmount.Text;

                    pocketMoney.TransactionDate = dtpTime.Value.ToString("dd-mm-yyyy");


                    output = PocketBLL.PocketMoneyInsert(pocketMoney);

                    if (output < 0)
                    {
                        lblMessage.Text = "FAIL";
                    }
                    else
                    {
                        lblMessage.Text = "SUCCESS";
                        LoadTransactionIds();
                        LoadTransaction();
                        LoadTransactionItems();
                        LoadTransaction1();
                        LoadTransaction2();
                        LoadTransactionDates();
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnDELETE_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete", " S I S",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = PocketBLL.PocketMoneyDelete(cmbID.Text);


                    if (output > 0)
                    {
                        lblMessage.Text = "SUCCESS";
                        LoadTransactionIds();
                        LoadTransaction();
                        LoadTransactionItems();
                        LoadTransaction1();
                        LoadTransaction2();
                        LoadTransactionDates();
                    }
                    else
                    {
                        lblMessage.Text = "FAIL";
                    }
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }


        }

        private void btnUPDATE_Click(object sender, EventArgs e)
        {
            PocketMoney pocketMoney = null;
            int output = 0;

            try
            {
                pocketMoney = new PocketMoney();
                pocketMoney.TransactionId = txtID.Text;
                pocketMoney.TransactionItem = cmbItems.Text;
                if (rbCredit.Checked)
                {
                    pocketMoney.TransactionType = "Credit";
                }
                else
                {
                    pocketMoney.TransactionType = "Debit";
                }
                pocketMoney.TransactionAmount = txtAmount.Text;
                pocketMoney.TransactionDate = dtpTime.Value.ToString("dd-mm-yyyy");


                output = PocketBLL.PocketMoneyUpdate(pocketMoney);

                if (output < 0)
                {


                    lblMessage.Text = "FAIL";

                }
                else
                {

                    lblMessage.Text = "SUCCESS";
                    LoadTransactionIds();
                    LoadTransaction();
                    LoadTransactionItems();
                    LoadTransaction1();
                    LoadTransaction2();
                    LoadTransactionDates();
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnCLEAR_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtAmount.Clear();
            cmbItems.Text = "";
            dtpTime.ResetText();


        }


        private void LoadTransactionIds()
        {
            DataSet dsTransactionIds = null;
            try
            {

                dsTransactionIds = PocketBLL.GetTransactionIds();
                if (dsTransactionIds != null)
                {
                    cmbID.DataSource = dsTransactionIds.Tables[0];
                    cmbID.ValueMember = "transaction_id";
                    cmbID.DisplayMember = "transaction_id";
                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void LoadTransaction()
        {
            DataSet dsTransactions = null;
            try
            {

                dsTransactions = PocketBLL.GetTransaction();
                if (dsTransactions != null)
                {
                    dgvPocketMoney.DataSource = dsTransactions.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {
            PocketMoney pocketMoney = null;
            try
            {

                pocketMoney = PocketBLL.GetTransactionById(cmbID.Text);

                if (pocketMoney != null)
                {
                    txtID.Text = pocketMoney.TransactionId;
                    cmbItems.Text = pocketMoney.TransactionItem;
                    txtAmount.Text = pocketMoney.TransactionAmount;
                    dtpTime.Text = pocketMoney.TransactionDate;

                    if (pocketMoney.TransactionType == "Credit")
                    {
                        rbCredit.Checked = true;
                        rbDebit.Checked = false;
                    }
                    else
                    {
                        rbCredit.Checked = false;
                        rbDebit.Checked = true;
                    }

                }
            }
            catch (Exception ex)
            {

            }
        }


        private void LoadTransactionItems()
        {
            DataSet dsTransactionItems = null;
            try
            {

                dsTransactionItems = PocketBLL.GetTransactionItems();
                if (dsTransactionItems != null)
                {
                    comboBox1.DataSource =cmbItems.Items;
                    comboBox1.ValueMember = "transaction_item";
                    comboBox1.DisplayMember = "transaction_item";
                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void LoadTransaction1()
        {
            DataSet dsTransactions = null;
            try
            {

                dsTransactions = PocketBLL.GetTransaction1();
                if (dsTransactions != null)
                {
                    dgvPocketMoney.DataSource = dsTransactions.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet dsTransactions = null;
            try
            {

                dsTransactions = PocketBLL.GetTransactionByItem(comboBox1.Text);

                if (dsTransactions != null)
                {
                    dgvPocketMoney.DataSource = dsTransactions.Tables[0];
                }
            }
            catch (Exception ex)
            {

            }
        }


        private void LoadTransactionDates()
        {
            DataSet dsTransactionDates = null;
            try
            {

                dsTransactionDates = PocketBLL.GetTransactionDate();
                if (dsTransactionDates != null)
                {
                    cmbSearchDate.DataSource = dsTransactionDates.Tables[0];
                    cmbSearchDate.ValueMember = "transaction_date";
                    cmbSearchDate.DisplayMember = "transaction_date";
                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void LoadTransaction2()
        {
            DataSet dsTransactions = null;
            try
            {

                dsTransactions = PocketBLL.GetTransaction2();
                if (dsTransactions != null)
                {
                    dgvPocketMoney.DataSource = dsTransactions.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No transactions available";
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void cmbSearchDate_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet dsTransactions = null;
            try
            {

                dsTransactions = PocketBLL.GetTransactionByDate(cmbSearchDate.Text);

                if (dsTransactions != null)
                {
                    dgvPocketMoney.DataSource = dsTransactions.Tables[0];
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
