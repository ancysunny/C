﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AddressBookDSL.AddressDL;
using AddressBookDTO.DTO;
using System.Data;

namespace AddressBookBLL.AddressBL
{
    public class AddressBLL
    {

        public static DataSet GetContactIds()
        {



            DataSet dsContact = null;
            try
            {
                 dsContact = AddressDSL.GetContactIds();


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:GetContactIds" + ex.Message.ToString());
            }

            return dsContact;
        }


        public static DataSet GetContact()
        {



            DataSet dsStudent = null;
            try
            {
                dsStudent = AddressDSL.GetContact();


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:GetContact" + ex.Message.ToString());
            }

            return dsStudent;
        }


        public static AddressBook GetContactById(string contactId)
        {



            AddressBook addressbook = null;
            try
            {

                addressbook = AddressDSL.GetContactById(contactId);

            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:GetContactById" + ex.Message.ToString());
            }

            return addressbook;
        }




        public static DataSet GetContactLike(string likeName)
        {

            DataSet dsContact = null;
            try
            {

                dsContact = AddressDSL.GetContactLike(likeName);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:GetContactLike" + ex.Message.ToString());
            }

            return dsContact;
        }



        public static int AddressInsert(AddressBook addressBook)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressInsert(addressBook);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:AddressInsert" + ex.Message.ToString());
            }

            return output;
        }


        public static int AddressDelete(string contactId)
        {
            int output = 0;

            try
            {
                output = AddressDSL.AddressDelete(contactId);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:AddressDelete" + ex.Message.ToString());
            }

            return output;
        }


        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;
            
            try
            {

                output = AddressDSL.AddressUpdate(addressBook);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressBLL.cs:AddressUpdate" + ex.Message.ToString());
            }
           
            return output;
        }

    }

}
