﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddressBookBLL.AddressBL;
using AddressBookDTO.DTO;

namespace AddressBookPL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblState_Click(object sender, EventArgs e)
        {

        }


        private void LoadContactIds()
        {
            DataSet dsContactIds = null;
            try
            {

                dsContactIds = AddressBLL.GetContactIds();
                if (dsContactIds != null)
                {
                    cmbID.DataSource = dsContactIds.Tables[0];
                    cmbID.ValueMember = "contactId";
                    cmbID.DisplayMember = "contactId";
                }
                else
                {
                    lblMessage.Text = "No Contacts available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void LoadContact()
        {
            DataSet dsContacts = null;
            try
            {

                dsContacts = AddressBLL.GetContact();
                if (dsContacts != null)
                {
                    dgvAddessBook.DataSource = dsContacts.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No Contacts available";
                }


            }
            catch (Exception ex)
            {

            }
        }





        private void btnSave_Click(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            int output = 0;


            try
            {
                if (txtID.Text == string.Empty || txtName.Text == string.Empty || cmbState.Text == string.Empty || txtEmail.Text == string.Empty || txtPhone.Text == string.Empty || txtCity.Text == string.Empty)
                {
                    lblMessage.Text = "Please enter the details !!!";
                    foreach (Control control in this.Controls)
                    {
                        // Set focus on control
                        control.Focus();
                        // Validate causes the control's Validating event to be fired,
                        // if CausesValidation is True
                        if (!Validate())
                        {
                            DialogResult = DialogResult.None;
                            return;
                        }
                    }
                } 
                  
                else 
                    {
                        addressBook = new AddressBook();
                        addressBook.ContactId = txtID.Text;
                        addressBook.Name = txtName.Text;
                        addressBook.DOB = dtpDOB.Value.ToString("dd-MM-yyyy");
                        //addressBook.DOB = dtpDOB.Text;
                        addressBook.City = txtCity.Text;
                        if (cmbState.SelectedIndex == -1)
                        {
                            lblMessage.Text ="Please select a state !!!";
                            return;
                        }
                        else
                        {
                            addressBook.State = cmbState.Text;
                        }
                        
                        if (txtEmail.Text == string.Empty || (!txtEmail.Text.Contains('@')))
                        {
                            lblMessage.Text = "Enter a valid email id !!!";
                            return;
                        }
                        else
                        {
                            addressBook.Email = txtEmail.Text;
                        }
                        if (txtPhone.Text == string.Empty || txtPhone.Text.Length != 10 && (!txtPhone.Text.StartsWith("0")))
                        {
                            lblMessage.Text = "Enter a valid mobile number !!!";
                            return;
                        }
                        else
                        {
                             addressBook.MobNo = txtPhone.Text;
                        }
                        if (!rbMale.Checked && !rbFemale.Checked)
                        {
                            lblMessage.Text = "Please Select gender !!!";
                            return;
                        }

                        else if (rbMale.Checked)
                        {
                            addressBook.Gender = "Male";
                        }
                        else
                        {
                            addressBook.Gender = "Female";
                        }



                        output = AddressBLL.AddressInsert(addressBook);

                        if (output < 0)
                        {


                            lblMessage.Text = "Try again later !!!";

                        }
                        else
                        {
                           
                            lblMessage.Text = "Contact saved successfully !!!";
                            LoadContactIds();
                            LoadContact();
                          
                        }
                    }
                }
                       

            catch (Exception ex)
            {
                //lblMessage.Text = ex.Message.ToString();
            }
                
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
           
                ClearControl();
                         
        } 
       
        private void ClearControl()
        {
            txtID.Clear();
            txtName.Clear();            
            txtCity.Clear();
            txtEmail.Clear();
            txtPhone.Clear();
            dtpDOB.ResetText();
            cmbState.Text = "";
            lblMessage.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete", " S I S",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = AddressBLL.AddressDelete(cmbID.Text);


                    if (output > 0)
                    {
                        lblMessage.Text = "Details deleted successfully !!!";
                        LoadContactIds();
                        LoadContact();
                    }
                    else
                    {
                        lblMessage.Text = "Try again later !!!";
                    }
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }


        }




        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'addressBookDBDataSet.address_book' table. You can move, or remove it, as needed.
            this.address_bookTableAdapter.Fill(this.addressBookDBDataSet.address_book);           
            LoadContactIds();
            LoadContact();
        }

        private void cmbID_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            try
            {

                addressBook = AddressBLL.GetContactById(cmbID.Text);

                if(addressBook!=null)
                {
                    txtID.Text = addressBook.ContactId;
                    txtName.Text = addressBook.Name;
                    txtCity.Text = addressBook.City;
                    cmbState.Text = addressBook.State;
                    txtPhone.Text = addressBook.MobNo;
                    txtEmail.Text = addressBook.Email;
                    dtpDOB.Text = addressBook.DOB.ToString();
                    if(addressBook.Gender=="Male")
                    {
                        rbMale.Checked = true;
                        rbFemale.Checked = false;
                    }
                    else
                    {
                        rbMale.Checked = false;
                        rbFemale.Checked = true;
                    }

                    
                    
                }


            }
            catch (Exception ex)
            {
                //lblMessage.Text = ex.Message.ToString();

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AddressBook addressBook = null;
            int output = 0;

            try
            {
                addressBook = new AddressBook();
                addressBook.ContactId = txtID.Text;
                addressBook.Name = txtName.Text;
                addressBook.DOB = dtpDOB.Value.ToString("dd-MM-yyyy");
                if (rbMale.Checked)
                {
                    addressBook.Gender = "Male";
                }
                else
                {
                    addressBook.Gender = "Female";
                }
                addressBook.City = txtCity.Text;
                addressBook.State = cmbState.Text;
                addressBook.Email = txtEmail.Text;
                addressBook.MobNo = txtPhone.Text;

               


                output = AddressBLL.AddressUpdate(addressBook);

                if (output < 0)
                {


                    lblMessage.Text = "Try again later !!!";

                }
                else
                {

                    lblMessage.Text = "Contact updated successfully !!!";
                    LoadContactIds();
                    LoadContact();

                }

            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void txtID_Validating(object sender, CancelEventArgs e)
        {
            if(txtID.Text == string.Empty)
            {
                ep1.SetError(txtID, "ID is required !");
            }
            else
            {
                ep1.SetError(txtID, string.Empty);
            }
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            if (txtName.Text == string.Empty)
            {
                ep1.SetError(txtName, "Name is required !");
            }
            else
            {
                ep1.SetError(txtName, string.Empty);
            }

        }

        private void txtCity_Validating(object sender, CancelEventArgs e)
        {
            if (txtCity.Text == string.Empty)
            {
                ep1.SetError(txtCity, "City name is required !");
            }
            else
            {
                ep1.SetError(txtCity, string.Empty);
            }
        }

        private void txtPhone_Validating(object sender, CancelEventArgs e)
        {
            if (txtPhone.Text == string.Empty)
            {
                ep1.SetError(txtPhone, "Mobile number is required !");
            }
            else
            {
                ep1.SetError(txtPhone, string.Empty);
            }
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            if (txtEmail.Text == string.Empty)
            {
                ep1.SetError(txtEmail, "Email id is required !");
            }
            else
            {
                ep1.SetError(txtEmail, string.Empty);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsContacts = null;
            try
            {
                string likeName = txtSearch.Text;
                dsContacts = AddressBLL.GetContactLike(likeName);
                if (dsContacts != null)
                {
                    dgvAddessBook.DataSource = dsContacts.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No contacts available";
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void cmbState_Validating(object sender, CancelEventArgs e)
        {

            if (cmbState.Text == string.Empty)
            {
                ep1.SetError(cmbState, "State name is required !");
            }
            else
            {
                ep1.SetError(cmbState, string.Empty);
            }
        }

        private void dtpDOB_Validating(object sender, CancelEventArgs e)
        {
            if (dtpDOB.Text == string.Empty)
            {
                ep1.SetError(dtpDOB, "State name is required !");
            }
            else
            {
                ep1.SetError(dtpDOB, string.Empty);
            }
        }

    }

}

   

