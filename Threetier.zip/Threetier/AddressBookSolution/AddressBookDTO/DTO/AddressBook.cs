﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddressBookDTO.DTO
{
    public class AddressBook
    {
        private string contactId;

        public string ContactId
        {
            get { return contactId; }
            set { contactId = value; }
        }


        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        private string dob;

        public string DOB
        {
            get { return dob; }
            set { dob = value; }
        }


        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }


        private string city;

        public string City
        {
            get { return city; }
            set { city = value; }
        }
        

        private string state;

        public string State
        {
            get { return state; }
            set { state = value; }
        }
        

        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        private string mobNo;

        public string MobNo
        {
            get { return mobNo; }
            set { mobNo = value; }
        }

    }
}
