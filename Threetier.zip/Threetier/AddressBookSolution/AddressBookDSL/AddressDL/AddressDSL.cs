﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using AddressBookDTO.DTO;
using AddressBookDSL.Helper;

namespace AddressBookDSL.AddressDL
{
    public class AddressDSL
    {


        public static DataSet GetContactIds()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            try
            {

                sql = "select contactId from address_book";

                con = DBhelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContactIds" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }


        public static DataSet GetContact()
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            try
            {

                sql = "select * from address_book";

                con = DBhelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContact" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }


        public static AddressBook GetContactById(string contactId)
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;
            AddressBook addressBook = null;
            try
            {

                sql = "select * from address_book where contactId='" + contactId + "'";

                con = DBhelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
                object[] Data = null;
                if (dsContact.Tables[0].Rows.Count > 0)
                {
                    Data = dsContact.Tables[0].Rows[0].ItemArray;
                    addressBook = new AddressBook();
                    addressBook.ContactId = Data[0].ToString();
                    addressBook.Name = Data[1].ToString();
                    addressBook.DOB = Data[2].ToString();
                    addressBook.Gender = Data[3].ToString();
                    addressBook.City = Data[4].ToString();
                    addressBook.State = Data[5].ToString();                  
                    addressBook.MobNo = Data[6].ToString();
                    addressBook.Email = Data[7].ToString();

                   
                }
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContactById" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return addressBook;
        }


        public static DataSet GetContactLike(string likeName)
        {

            string sql = "";
            SqlConnection con = null;
            SqlDataAdapter adapter = null;
            DataSet dsContact = null;

            try
            {

                sql = "select * from address_book where name like '" + likeName + "%'";

                con = DBhelper.GetConnection();

                con.Open();

                dsContact = new DataSet();
                adapter = new SqlDataAdapter(sql, con);
                adapter.Fill(dsContact);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:GetContactLike" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                adapter.Dispose();
            }
            return dsContact;
        }

        public static int AddressInsert(AddressBook addressBook)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;
            
            try
            {
                sql = "insert into address_book (contactId,name,dob,gender,city,state,email,mobNo) values (";
                sql = sql + "'" + addressBook.ContactId + "',";
                sql = sql + "'" + addressBook.Name + "',";
                sql = sql + "'" + addressBook.DOB + "',";
                sql = sql + "'" + addressBook.Gender + "',";
                sql = sql + "'" + addressBook.City + "',";
                sql = sql + "'" + addressBook.State + "',";
                sql = sql + "'" + addressBook.Email + "',";
                sql = sql + "'" + addressBook.MobNo + "')";

                con = DBhelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:AddressInsert" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



        public static int AddressDelete(string contactId)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "delete from address_book where contactId='" + contactId + "'";


                con = DBhelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:AddressDelete" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }


        public static int AddressUpdate(AddressBook addressBook)
        {
            int output = 0;
            string sql = "";
            SqlConnection con = null;
            SqlCommand cmd = null;

            try
            {
                sql = "update address_book set ";
                sql = sql + "name = '" + addressBook.Name + "',";
                sql = sql + "dob = '" + addressBook.DOB + "',";
                sql = sql + "gender = '" + addressBook.Gender + "',";
                sql = sql + "city = '" + addressBook.City + "',";
                sql = sql + "state = '" + addressBook.State + "',";
                sql = sql + "email = '" + addressBook.Email + "',";
                sql = sql + "mobNo = '" + addressBook.MobNo + "' ";
                sql = sql + "where contactId ='" + addressBook.ContactId + "'";

                con = DBhelper.GetConnection();
                con.Open();
                cmd = new SqlCommand(sql, con);

                output = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:AddressDSL.cs:AddressUpdate" + ex.Message.ToString());
            }
            finally
            {
                con.Close();
                cmd.Dispose();
            }
            return output;
        }



    }
}
