﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinTrustApp.PresentationLayer
{
    public partial class FinTrust_AccountClose : Form
    {
        public FinTrust_AccountClose()
        {
            InitializeComponent();
        }
    }
}
