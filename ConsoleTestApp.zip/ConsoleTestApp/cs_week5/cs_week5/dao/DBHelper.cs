﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace cs_week5.dao
{
    class DBHelper
    {
        public static SqlConnection GetConnection()
        {

            SqlConnection con = null;
            string connectionString = null;

            try
            {
                connectionString = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1028270\\Desktop\\ancysunny\\cs_week5\\cs_week5\\StudentDB.mdf;Integrated Security=True";
                con = new SqlConnection(connectionString);
                
            }
            catch(Exception ex)
            {
                Console.Out.WriteLine("******Error:DBHelper.cs:GetConnection" + ex.Message.ToString());
            }
            return con;

        }
    }
}
