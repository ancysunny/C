﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs_week5.Helper
{
    class UtilityHelper
    {

        public static string GenerateID(string oldID)
        {
            string newId = null;
            string prefix, sufix;
            int next;
            try
            {

               
                prefix = oldID.Substring(0, 3);
                sufix = oldID.Substring(3);
                next = Convert.ToInt32(sufix) + 1;
                newId = prefix + next;


            }
            catch(Exception ex)
            {
                Console.Out.WriteLine("******Error:UtilityHelper.cs:GenerateID" + ex.Message.ToString());
            }

            return newId;
        }

    }
}
