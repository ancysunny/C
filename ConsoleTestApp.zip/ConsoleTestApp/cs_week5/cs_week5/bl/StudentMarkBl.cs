﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cs_week5.dto;
using cs_week5.dao;
using System.Data;
using cs_week5.Helper;

namespace cs_week5.bl
{
    class StudentMarkBl
    {

        public static int StudentMarkInsert(StudentMark studentMark)
        {
            int output = 0;

            try
            {
                studentMark.Total = studentMark.Mark1 + studentMark.Mark2 + studentMark.Mark3;

                if (studentMark.Mark1 < 50 || studentMark.Mark2 < 50 || studentMark.Mark3 < 50)
                {
                    studentMark.Result = "FAIL";
                }
                else
                {
                    studentMark.Result = "PASS";
                }


                output = StudentMarkDao.StudentMarkInsert(studentMark);


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:StudentMarkBl.cs:StudentMarkInsert" + ex.Message.ToString());
            }
            return output;
        }


        public static int StudentMarkDelete(string studentId)
        {
           int output=0;
            try

            {
                output = StudentMarkDao.StudentMarkDelete(studentId);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:StudentMarkBl.cs:StudentMarkDelete" + ex.Message.ToString());
            }
            
            return output;
        }


        public static int StudentMarkUpdate(StudentMark studentMark)
        {
            int output = 0;
            try
            {

                studentMark.Total = studentMark.Mark1 + studentMark.Mark2 + studentMark.Mark3;

                if (studentMark.Mark1 < 50 || studentMark.Mark2 < 50 || studentMark.Mark3 < 50)
                {
                    studentMark.Result = "FAIL";
                }
                else
                {
                    studentMark.Result = "PASS";
                }



                output = StudentMarkDao.StudentMarkUpdate(studentMark);
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("******Error:StudentMarkBl.cs:StudentMarkUpdate" + ex.Message.ToString());
            }
           
            return output;
        }

         public static DataSet GetStudentIds()
        {
            
            
           
            DataSet dsStudent = null;
            try
            {
                dsStudent = StudentMarkDao.GetStudentIds();
   
                
            }
            catch(Exception ex)
            {
                Console.Out.WriteLine("******Error:StudentMarkDao.cs:GetStudentIds" + ex.Message.ToString());
            }
            
            return dsStudent;
        }

         public static string GetnewStudentIds()
         {

            
             
             string LastStudentId = null;
             string newStudentId = null;

    
             try
             {

                 LastStudentId = StudentMarkDao.GetLastStudentIds();

                 if(LastStudentId!=null)
                 {
                     newStudentId = UtilityHelper.GenerateID(LastStudentId);

                 }
                 else
                 {
                     newStudentId = "STU101";
                 }

             }
             catch (Exception ex)
             {
                 Console.Out.WriteLine("******Error:StudentMarkBl.cs:GetLastStudentIds" + ex.Message.ToString());
             }
             
             return newStudentId;
         }




         public static DataSet GetStudent()
         {



             DataSet dsStudent = null;
             try
             {
                 dsStudent = StudentMarkDao.GetStudent();


             }
             catch (Exception ex)
             {
                 Console.Out.WriteLine("******Error:StudentMarkDao.cs:GetStudent" + ex.Message.ToString());
             }

             return dsStudent;
         }


         public static DataSet GetStudentLike(string likeName)
         {

             DataSet dsStudent = null;
             try
             {

                 dsStudent = StudentMarkDao.GetStudentLike(likeName);
             }
             catch (Exception ex)
             {
                 Console.Out.WriteLine("******Error:StudentMarkBl.cs:GetStudentLike" + ex.Message.ToString());
             }

             return dsStudent;
         }



         public static StudentMark GetStudentById(string studentId)
         {

            
            
             StudentMark studentMark = null;
             try
             {

                 studentMark = StudentMarkDao.GetStudentById(studentId);
                 
             }
             catch (Exception ex)
             {
                 Console.Out.WriteLine("******Error:StudentMarkBl.cs:GetStudentById" + ex.Message.ToString());
             }
             
             return studentMark;
         }

    }


}
