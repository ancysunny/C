﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using cs_week5.dto;
using cs_week5.dao;
using cs_week5.bl;


namespace cs_week5
{
    public partial class StudentMaster : Form
    {
        int countMark1 = 0; bool flagMark1 = false;
        int countMark2 = 0; bool flagMark2 = false;
        int countMark3 = 0; bool flagMark3 = false;
        public StudentMaster()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoadStudentIds()
        {
            DataSet dsStudentIds = null;
            try
            {

                dsStudentIds = StudentMarkBl.GetStudentIds();
                if (dsStudentIds != null)
                {
                    cmbStudentID.DataSource = dsStudentIds.Tables[0];
                    cmbStudentID.ValueMember = "student_id";
                    cmbStudentID.DisplayMember = "student_id";
                }
                else
                {
                    lblMessage.Text = "No students available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void LoadStudent()
        {
            DataSet dsStudents = null;
            try
            {

                dsStudents = StudentMarkBl.GetStudent();
                if (dsStudents != null)
                {
                    dgvStudent.DataSource = dsStudents.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No students available";
                }


            }
            catch (Exception ex)
            {

            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            StudentMark studentMark = null;
            int output = 0;


            try
            {

                if (btnSave.Text == "NEW")
                {
                    btnSave.Text = "SAVE";
                    ClearControl();
                    txtID.Text = StudentMarkBl.GetnewStudentIds();


                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnClear.Text = "BACK";

                }

                else
                {
                    studentMark = new StudentMark();
                    studentMark.StudentID = txtID.Text;
                    studentMark.StudentName = txtName.Text;
                    studentMark.Mark1 = Convert.ToInt32(txtMark1.Text);
                    studentMark.Mark2 = Convert.ToInt32(txtMark2.Text);
                    studentMark.Mark3 = Convert.ToInt32(txtMark3.Text);

                    output = StudentMarkBl.StudentMarkInsert(studentMark);

                    if (studentMark.Mark1 < 0 || studentMark.Mark2 > 100)
                    {
                        lblMessage.Text = "Mark should be between 0-100";
                        txtMark1.Focus();
                    }
                    else
                    {
                        output = StudentMarkBl.StudentMarkInsert(studentMark);


                        if (output < 0)
                        {


                            lblMessage.Text = "FAIL";


                        }
                        else
                        {
                            LoadStudentIds();
                            LoadStudent();
                            lblMessage.Text = "SUCCESS";

                            btnSave.Text = "NEW";
                            btnDelete.Enabled = true;
                            btnUpdate.Enabled = true;
                            btnClear.Text = "CLEAR";

                        }
                    }
                }


            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }



        private void StudentMaster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDBDataSet1.student_mark' table. You can move, or remove it, as needed.
            this.student_markTableAdapter.Fill(this.studentDBDataSet1.student_mark);
            LoadStudentIds();
            LoadStudent();
        }

        private void cmbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //      MessageBox.Show(cmbStudentID.Text);

            StudentMark studentMark = null;
            try
            {

                studentMark = StudentMarkBl.GetStudentById(cmbStudentID.Text);

                if (studentMark != null)
                {
                    txtID.Text = studentMark.StudentID;
                    txtName.Text = studentMark.StudentName;
                    txtMark1.Text = studentMark.Mark1.ToString();
                    txtMark2.Text = studentMark.Mark2.ToString();
                    txtMark3.Text = studentMark.Mark3.ToString();

                }


            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();

            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete", " S I S",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    output = StudentMarkBl.StudentMarkDelete(cmbStudentID.Text);


                    if (output > 0)
                    {
                        lblMessage.Text = "Details deleted successfully...";
                        LoadStudentIds();
                        LoadStudent();
                    }
                    else
                    {
                        lblMessage.Text = "Try again later";
                    }
                }

            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StudentMark studentMark = null;
            int output = 0;


            try
            {
                studentMark = new StudentMark();
                studentMark.StudentID = txtID.Text;
                studentMark.StudentName = txtName.Text;
                studentMark.Mark1 = Convert.ToInt32(txtMark1.Text);
                studentMark.Mark2 = Convert.ToInt32(txtMark2.Text);
                studentMark.Mark3 = Convert.ToInt32(txtMark3.Text);

                output = StudentMarkBl.StudentMarkUpdate(studentMark);

                if (studentMark.Mark1 < 0 || studentMark.Mark2 > 100)
                {
                    lblMessage.Text = "Mark should be between 0-100";
                }
                else
                {
                    output = StudentMarkBl.StudentMarkUpdate(studentMark);


                    if (output > 0)
                    {
                        lblMessage.Text = "Details updated successfully!!";
                        LoadStudent();

                    }
                    else
                    {
                        lblMessage.Text = "Try again later....";
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            if (btnClear.Text == "BACK")
            {
                btnSave.Text = "NEW";
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
                btnClear.Text = "CLEAR";
            }
            else
            {
                ClearControl();
            }


        }

        private void ClearControl()
        {
            txtID.Clear();
            txtName.Clear();
            txtMark1.Clear();
            txtMark2.Clear();
            txtMark3.Clear();
            lblMessage.Text = "";
        }

        private void lblNameSearch_Click(object sender, EventArgs e)
        {

        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsStudents = null;
            try
            {
                string likeName = txtNameSearch.Text;
                dsStudents = StudentMarkBl.GetStudentLike(likeName);
                if (dsStudents != null)
                {
                    dgvStudent.DataSource = dsStudents.Tables[0];

                }
                else
                {
                    lblMessage.Text = "No students available";
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void txtMark1_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark1 = false;

            if(!txtMark1.Text.Contains(".") && countMark1 > 0)
            {
                countMark1--;
            }

            if((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)|| (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) || (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) && countMark1 < 1||e.KeyCode == Keys.Back)
            {
                flagMark1 = true;
                if(e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                {
                    countMark1++;
                }
            }

        }

        private void txtMark1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!flagMark1)
            {
                e.Handled = true;
            }
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvStudent_SelectionChanged(object sender, EventArgs e)
        {
            string studentId, student_name;
            int mark1, mark2, mark3;

            if(dgvStudent.SelectedCells.Count > 0 )
            {
                int selectedrowindex = dgvStudent.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dgvStudent.Rows[selectedrowindex];

                studentId = Convert.ToString(selectedRow.Cells["student_id"].Value);
                student_name = Convert.ToString(selectedRow.Cells["student_name"].Value);
                mark1 = Convert.ToInt32(selectedRow.Cells["mark1"].Value);
                mark2 = Convert.ToInt32(selectedRow.Cells["mark2"].Value);
                mark3 = Convert.ToInt32(selectedRow.Cells["mark3"].Value);

                txtID.Text = studentId;
                txtName.Text = student_name;
                txtMark1.Text = mark1.ToString();
                txtMark2.Text = mark2.ToString();
                txtMark3.Text = mark3.ToString();
            }












        }
        //            SqlConnection con = null;
        //            SqlCommand cmd = null;
        //            string connectionString = null;
        //            string sql = null;

        //            string student_id, student_name, result;
        //            int mark1, mark2, mark3, total;

        //            int output = 0;

        //            try
        //            {
        //                connectionString="Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\1028270\\Desktop\\ancysunny\\cs_week5\\cs_week5\\StudentDB.mdf;Integrated Security=True";
        //                con = new SqlConnection(connectionString);

        //                student_id = txtID.Text;
        //                student_name = txtName.Text;
        //                mark1 = Convert.ToInt32(txtMark1.Text);
        //                mark2 = Convert.ToInt32(txtMark2.Text);
        //                mark3 = Convert.ToInt32(txtMark3.Text);

        //                total = mark1 + mark2 + mark3;

        //                if(mark1<50||mark2<50||mark3<50)
        //                {
        //                    result = "FAIL";
        //                }
        //                else
        //                {
        //                    result = "PASS";
        //                }


        //                sql = "insert into student_mark (student_id,student_name,mark1,mark2,mark3,total,result) values (";
        //                sql = sql + "'" + student_id + "',";
        //                sql = sql + "'" + student_name + "',";
        //                sql = sql + mark1 + ",";
        //                sql = sql + mark2 + ",";
        //                sql = sql + mark3 + ",";
        //                sql = sql + total + ",";
        //                sql = sql + "'" + result + "')";


        //                con.Open();
        //                cmd = new SqlCommand(sql, con);

        //                output = cmd.ExecuteNonQuery();
        //                if(output>0)
        //                {
        //                    lblMessage.Text = "SUCCESS";

        //                }
        //                else
        //                {
        //                    lblMessage.Text = "FAIL";
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                lblMessage.Text = ex.Message.ToString();
        //            }

        //            finally
        //            {
        //                con.Close();
        //                cmd.Dispose();
        //            }

    }
}
   

