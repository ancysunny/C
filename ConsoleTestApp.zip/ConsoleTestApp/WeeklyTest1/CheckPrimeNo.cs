﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class CheckPrimeNo
    {
        int num,result;

        public void ReadData()
        {
            Console.Write("Enter the number: ");
            num = Convert.ToInt32(Console.ReadLine());
        }

        public void CheckPrime()
        {
            for(int i=2;i<num;i++)
            {
                 result = num % i;
            }
        }

        public void DisplayData()
        {
            if(result==0)
            {
                Console.WriteLine("PRIME NUMBER");

            }
            else
            {
                Console.WriteLine("NOT PRIME NUMBER");
            }
        }

        public static void Main()
        {
            CheckPrimeNo check = new CheckPrimeNo();
            check.ReadData();
            check.CheckPrime();
            check.DisplayData();
            Console.ReadKey();
        }
    }
}
