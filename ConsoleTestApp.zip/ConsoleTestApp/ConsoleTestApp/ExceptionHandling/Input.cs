﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.ExceptionHandling
{
    class Input
    {

        public static void main()
        {
            Console.WriteLine("Enter a number:");
            int n = Convert.ToInt32(Console.ReadLine());
            Input.ReadI();

            Console.ReadKey();
        }
        public static int ReadI()
        {

            int value = 0;
            bool flag = true;
            do
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    flag = false;
                }

                catch
                {
                    Console.WriteLine("Wrong value.............Enter a valid no:");
                }
            } while (flag);
            return value;
        }
    }
}
