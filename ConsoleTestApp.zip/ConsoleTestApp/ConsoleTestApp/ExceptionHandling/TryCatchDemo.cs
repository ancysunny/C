﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.ExceptionHandling
{
    class TryCatchDemo
    {

        public static void Main()
        {
            int a=20, b=0,c;

            try
            {
                 c = a / b;
            }

            catch(Exception e)
            {
                Console.WriteLine("error:"+e.Message.ToString());
                c = a / 2;
                Console.WriteLine("C : "+c);

            }

            Console.ReadKey();

        }
    }
}
