﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fact
    {
        int n;
        int facto = 1;

        public void ReadData()
        {
            Console.WriteLine("ENTER THE NO:");
            n = Convert.ToInt32(Console.ReadLine());

        }

        public void FindFact()
        {

            int i;
            
            for(i=1;i<=n;i++)
            {
                facto *= i;

            }
        }

        public void DisplayData()
        {

            Console.WriteLine("Factorial ="+facto);
        }

        public static void Main()
        {
            Fact objFact = new Fact();
            objFact.ReadData();
            objFact.FindFact();
            objFact.DisplayData();

            Console.ReadKey();

        }

    }
}
