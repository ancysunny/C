﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo1
    {
        int a = 2;
        static int b = 3;
        public void display()
        {
            Console.WriteLine("a = " + a);
            Console.WriteLine("b = " + b);
            a++;
            b++;
        }
        public static void Main()
        {
            StaticDemo1 ab =new StaticDemo1();
            StaticDemo1 bc = new StaticDemo1();
            StaticDemo1 cd = new StaticDemo1();
            ab.display();
            bc.display();
            cd.display();

            Console.ReadKey();

        }
    }
}
