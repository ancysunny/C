﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibinocci
    {
        int n;

        public void ReadData()
        {
            Console.Write("Enter the limit: ");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void display()
        {
            int i=0;
            int a=0;
            int b=1;
            Console.Write(a+" ");
            Console.Write(b + " ");
            while(i<=n)
            {
                i = a + b;
                Console.Write(i + " ");
                a = b;
                b = i;
            }
        }

        public static void Main()
        {
            Fibinocci fib = new Fibinocci();
            fib.ReadData();
            fib.display();

            Console.ReadKey();

        }
    }
}
