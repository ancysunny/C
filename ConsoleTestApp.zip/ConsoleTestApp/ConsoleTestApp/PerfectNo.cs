﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PerfectNo
    {
        int n;
        int perfectNo=0;

        public void ReadData()
        {
            Console.Write("Enter the number: ");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void perfect()
        {
            int num = n;
            int i;
            for(i=1;i<num;i++)
            {
                if(num%i==0)
                {                   
                    perfectNo += i;

                }
            }
        }

        public void Display()
        {
            if (perfectNo == n)
            {
                Console.Write("Perfect No ");
            }
            else
            {
                Console.Write("Not Perfect No");
            }
        }

        public static void Main()
        {
            PerfectNo per = new PerfectNo();
            per.ReadData();
            per.perfect();
            per.Display();

            Console.ReadKey();

        }
    }
}
