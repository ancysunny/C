﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Indexers
{
    class IndexersDemo
    {
        public static void Main()
        {
            Marks mark = new Marks();
            mark[0] = 100;
            for(int i=1;i<5;i++)
            {
                mark[i] = mark[i - 1] + 5;

            }

            for (int i = 0; i <5; i++)
            {
                Console.WriteLine(mark[i] + " ");

            }

            Console.ReadKey();
        }




        class Marks
        {
            static int noOfStudents = 5;

            public int[] mark = new int[5];


            public int this[int index]
            {
                get { return mark[index]; }
                set { mark[index] = value; }
            }
        }
    }
}