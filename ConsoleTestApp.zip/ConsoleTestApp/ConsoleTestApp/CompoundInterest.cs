﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class CompoundInterest
    {
       
            public static void Main()
            {
                Console.WriteLine("Compund Interest = "+FindCompoundInterest(1000, 2, 2, 2));
                Console.ReadKey();
            }

            /// <summary>
            /// CompoundInterest.
            /// </summary>
            public static double FindCompoundInterest(double principal,
                double interestRate,
                int timesPerYear,
                double years)
            {
                // (1 + r/n)
                double body = 1 + ((interestRate/100) / timesPerYear);

                // nt
                double exponent = timesPerYear * years;

                // P(1 + r/n)^nt
                return principal * Math.Pow(body, exponent);
            }
        
    }
}
