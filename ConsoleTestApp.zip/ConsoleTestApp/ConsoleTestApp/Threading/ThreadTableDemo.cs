﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.Threading
{
    class ThreadTableDemo
    {

        public static void Main()
        {
            Table table5 = new Table(5,200);
            Thread th1 = new Thread(table5.GenerateTable);
            th1.Start();

            Table table3 = new Table(3, 5000);
            Thread th2 = new Thread(table3.GenerateTable);
            th2.Start();

            Console.ReadKey();
        }
    }





    class Table
    {
        private int _num;
        private int _sleep;

        public Table (int target,int sleep)
        {
            _num = target;
            _sleep = sleep;
        }
        public void GenerateTable()
        {
            Thread.Sleep(_sleep);
            for(int iteration=1;iteration <=10;iteration ++)
            {
                Console.WriteLine("{0} * {1} = {2}", iteration, _num, (iteration * _num));
            }
        }
    }
}
