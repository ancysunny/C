﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace ConsoleTestApp.Threading
{
    class LockDemo
    {


        public static void Main()
        {
            Printer p= new Printer();
            Thread th1 = new Thread(p.Printable);
            th1.Start();
          
            Thread th2 = new Thread(p.Printable);
            th2.Start();

            Console.ReadKey();

        }
    }


    class Printer
    {
        public void Printable()
        {
            
            lock(this)
            {
                
                for( int i=1;i<=10;i++)
                {
                    Thread.Sleep(1000);
                    Console.WriteLine(i);
                }
            }
        }
    }
}
