﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ConsoleTestApp.Threading
{
    class JoinDemo
    {

        public static void Main()
        {
            Thread th1 = Thread.CurrentThread;
            th1.Name = "Main Thread";
            Console.WriteLine("Main Method: " + th1.Name);

             
            ThreadStart th1start = new ThreadStart(ChildThread1);


            Thread subth1 = new Thread(ChildThread1);
            Thread subth2 = new Thread(ChildThread2);
            subth1.Start();
            subth2.Start();

            //subth1.Join();
            subth2.Join();
            Console.WriteLine("Main method completed");
            Console.WriteLine();

            Console.ReadKey();
        }


        public static void ChildThread1()
        {
            Console.WriteLine("I am in child thread1");
            for (int i = 0; i <= 10; i++)
            {
                Console.Write(i + " ");

            }
            Console.WriteLine();
            Console.WriteLine("Child thread1 completed");
        }

        public static void ChildThread2()
        {
            //Thread.Sleep(1000);
            Console.WriteLine("I am in child thread2");
            for (int i = 0; i <= 10; i++)
            {
                Console.Write(i + " ");

            }
            Console.WriteLine();
            Console.WriteLine("Child thread2 completed");
        }
    }
}
