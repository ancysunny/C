﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo
    {
        public static void Main()
        {

        
        Console.WriteLine("2+3 = "+Calculate.sum(2,3));

        Calculate objCalculate = new Calculate();
        Console.WriteLine("20-5 = " + objCalculate.diff(20, 5));

        Console.ReadKey();


        }

    }
}
