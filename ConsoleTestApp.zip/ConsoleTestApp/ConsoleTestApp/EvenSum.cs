﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class EvenSum
    {
        int n;
        int sum = 0;

        public void ReadData()
        {
            Console.Write("Enter the limit:");
            n=Convert.ToInt32(Console.ReadLine());
        }

        public void FindSum()
        {
            int i;
            for(i=0;i<=n;i++)
            {
                sum += i;
                i++;

                
            }
        }

        public void DisplayData()
        {
            Console.WriteLine("sum = " + sum);
        }

        public static void Main()
        {
            EvenSum objsum = new EvenSum();
            objsum.ReadData();
            objsum.FindSum();
            objsum.DisplayData();
            Console.ReadKey();
        }
    }
}
