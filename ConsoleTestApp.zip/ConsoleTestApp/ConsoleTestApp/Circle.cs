﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Circle
    {
        double r,Area,Circumference;
        double pi = 3.14159;

        public void ReadCircle()
        {
            Console.WriteLine("Enter the radius:");
            r=Convert.ToInt32(Console.ReadLine());

        }

        public void FindArea()
        {
            Area=pi*r*r;
            Console.WriteLine("Area =" + Area);

        }

        public void FindCircumference()
        {

            Circumference = 2 * pi * r;
            Console.WriteLine("Circumference =" + Circumference);

        }

        public static void Main()
        {

            Circle objCircle = new Circle();
            objCircle.ReadCircle();
            objCircle.FindArea();
            objCircle.FindCircumference();
            

            Console.ReadKey();

        }
    }
}
