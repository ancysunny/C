﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractAssignment
    {
        public static void Main()
        {
            Square sq = new Square();
            sq.ReadData();
            sq.FindArea();
            sq.display();

            Triangle tr = new Triangle();
            tr.ReadData();
            tr.FindArea();
            tr.display();

            Console.ReadKey();

        }
    }

    abstract class shape
    {
        public double area;

        public abstract void FindArea();

        

        public void display()
        {
            Console.Write("Area : "+area);
            Console.WriteLine("");
        }
    }

    class Square : shape
    {
        int a;
        public void ReadData()
        {           
            Console.Write("Enter the side : ");
            a = Convert.ToInt32(Console.ReadLine());
        }
        public override void FindArea()
        {
          area = a*a;
        }
    }

    
    class Triangle : shape
    {
        int b,h;
        public void ReadData()
        {
            Console.Write("Enter the breadth : ");
            b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the height : ");
            h = Convert.ToInt32(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = 0.5*b*h;
        }
    }
}
