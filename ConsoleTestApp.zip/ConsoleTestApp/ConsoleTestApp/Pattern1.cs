﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern1
    {
        int i, j,n=4;
        public void FindPattern1()
        {
            for(i=1;i<=n;i++)
            {
               
                for(j=1;j<=i;j++)
                {
                    Console.Write(" * ");
                }

                Console.WriteLine();
            }
        }

       

        public static void Main()
        {
            Pattern1 objPat = new Pattern1();
            objPat.FindPattern1();            
            Console.WriteLine();           
            Console.ReadKey();


        }


    }

    }

