﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Student
    {
        static int min_mark=0, max_mark=100, pass_mark=25;
        int id, mark1;
        string name;

        public void ReadData()
        {
            Console.WriteLine("");
            Console.Write("id : ");
            id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Name : ");
            name = Convert.ToString(Console.ReadLine());
            Console.Write("Mark : ");
            mark1 = Convert.ToInt32(Console.ReadLine());           
           
        }

        public void CheckMark()
        {
            bool flag = false;
            do{
                if(mark1<min_mark || mark1>max_mark)
                {
                    flag = true;
                    Console.WriteLine("**********INVALID*********");
                    Console.Write("mark : ");
                    mark1 = Convert.ToInt32(Console.ReadLine());
                    DisplayData();
                }
                
            }while(flag);
        }

        public void DisplayData()
        {
            Student.pass_mark = 45;
            if(mark1<pass_mark)
            {
                Console.WriteLine("");
                Console.WriteLine("FAILED");
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine("PASSED");
            }

        }

        public static void Main()
        {
            Student a = new Student();
            a.ReadData();
            a.CheckMark();
            a.DisplayData();
           

            Student b = new Student();
            b.ReadData();
            b.CheckMark();
            b.DisplayData();
            Console.ReadKey();

            

        }

    }

    
}
