﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegates
{
    public delegate bool IsTopperDelegate(Student student);
    class StudentDelegate
    {

        public static void Main()
        {

            List<Student> studentList = new List<Student>();

            studentList.Add(new Student { ID = 001, Name = "ABC", Marks = 48, Grade = 'A'});
            studentList.Add(new Student { ID = 002, Name = "DES", Marks = 23, Grade = 'B' });
            studentList.Add(new Student { ID = 003, Name = "RTY", Marks = 40, Grade = 'A' });
            studentList.Add(new Student { ID = 004, Name = "XYZ", Marks = 42, Grade = 'A' });
            studentList.Add(new Student { ID = 005, Name = "QWR", Marks = 34, Grade = 'B' });

            IsTopperDelegate topperdelegate = new IsTopperDelegate(IsTopper);
            Student.GetTopperList(studentList, topperdelegate);

            Console.ReadKey();


        }



        public static bool IsTopper(Student student)
        {
            bool topper = false;
            if(student.Marks >=40 && student.Grade =='A')
            {
                topper = true;
            }
            return topper;
        }
    }





    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Marks { get; set; }
        public char Grade { get; set; }

        public static void GetTopperList(List<Student> students, IsTopperDelegate topperdelegate)
        {
            foreach(Student student in students)
            {
                if(topperdelegate(student))
                {
                    Console.WriteLine("Student ID : {0}", student.ID);
                    Console.WriteLine("Student Name : {0}", student.Name);
                    Console.WriteLine("Student Marks : {0}", student.Marks);
                    Console.WriteLine("Student Grade : {0}", student.Grade);
                    Console.WriteLine(" ");
                }
            }

        }


    }
}

