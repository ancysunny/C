﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegates
{
    public delegate void Calculate(int a,int b);                                                                //delegate declaration
    class DelegateDemo
    {
        public static void Main()
        {
            Calculator cal = new Calculator();           
            Calculate calculate = new Calculate(Calculator.Sum);                                                 //delegate object creation
            calculate += calculator1.Sub;
            calculate += cal.mul;                                                          //Multicast delegates
            calculate(3, 5);
            Console.ReadKey();

        }
    }

    class Calculator
    {
        public static void Sum(int a,int b)
        {
            Console.WriteLine(a + b);
        }
        public void mul(int a, int b)
        {
            Console.WriteLine(a * b);
        }
    }
    class calculator1
    {
        public static void Sub(int a,int b)
        {
            Console.WriteLine(a - b);
        }
    }

}
