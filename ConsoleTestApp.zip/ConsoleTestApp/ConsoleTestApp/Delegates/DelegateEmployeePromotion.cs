﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegates
{
    public delegate bool IsPromotableDelegate(Employee employee);

    class DelegateEmployeePromotion
    {


        public static void Main()
        {

            List<Employee> employeeList = new List<Employee>();

            employeeList.Add(new Employee { ID = 101, Name = "Anu", Salary = 236714, Experience = 5 });
            employeeList.Add(new Employee { ID = 102, Name = "Ammu", Salary = 674574, Experience = 6 });
            employeeList.Add(new Employee { ID = 103, Name = "Appu", Salary = 213323, Experience = 4 });
            employeeList.Add(new Employee { ID = 104, Name = "Aashu", Salary = 54577, Experience = 9 });
            employeeList.Add(new Employee { ID = 105, Name = "Aaghu", Salary = 8796564, Experience = 3 });

            Console.WriteLine("List of employees eligible for promotion:");
            Console.WriteLine(" ");
            //Employee.GetPromotedList(employeeList);

           IsPromotableDelegate ispromotablDelegate = new IsPromotableDelegate(IsPromotable);
           Employee.GetPromotedList(employeeList, ispromotablDelegate);

           Console.ReadKey();
        }

             public static bool IsPromotable(Employee employee)
            {
                 bool eligible=false;
                 if(employee.Experience >=4 && employee.Salary <5000)
                 {
                     eligible=true;
                 }
                 return eligible;
            }
       
    }




   public class Employee
    {

        public int ID { get; set; }

        public string Name { get; set; }

        public int Salary { get; set; }

        public int Experience { get; set; }


        //public static void GetPromotedList(List<Employee> employees)
        //{
        //    foreach(Employee employee in employees)
        //    {
        //        if(employee.Experience>=5)
        //        {
        //            Console.WriteLine("Employee ID {0}", employee.ID);
        //            Console.WriteLine("Employee Name {0}", employee.Name);
        //            Console.WriteLine("Employee Salary {0}", employee.Salary);
        //            Console.WriteLine("Employee Experience {0}", employee.Experience);
        //            Console.WriteLine(" ");
        //        }
        //    }
        //}

        public static void GetPromotedList(List<Employee> employees, IsPromotableDelegate ispromotablDelegate)
        {
            foreach (Employee employee in employees)
            {
                if (ispromotablDelegate(employee))
                {
                    Console.WriteLine("Employee ID {0}", employee.ID);
                    Console.WriteLine("Employee Name {0}", employee.Name);
                    Console.WriteLine("Employee Salary {0}", employee.Salary);
                    Console.WriteLine("Employee Experience {0}", employee.Experience);
                    Console.WriteLine(" ");
                }
            }

        }
    }
}
