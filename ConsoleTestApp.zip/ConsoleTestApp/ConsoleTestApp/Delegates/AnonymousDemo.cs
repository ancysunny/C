﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Delegates
{
    public delegate void print(int value);
    class AnonymousDemo
    {
        public static void Main()
        {
            //print print = delegate(int val)
            //{

            //    Console.WriteLine("I AM INSIDE ANONYMOUS METHOD......value: {0}", val);
            //};
           
           
            //    print(200);


            PrintHelperMethod(delegate(int val) { Console.WriteLine("Anonymous method: {0}", val); }, 100);

                Console.ReadKey();
            
        }

        public static void PrintHelperMethod(print PrintDel,int val)
        {
            val += 10;
            PrintDel(val);
        }
    }
}
