﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SwitchCaseMenu
    {

        public static void Main()
        {
            int choice;
            do
            {
                Console.WriteLine("*************");
                Console.WriteLine("1. Digit Sum");
                Console.WriteLine("2. Prime no");
                Console.WriteLine("3.Exit");
                Console.WriteLine("*************");
                Console.WriteLine("Enter the option:");
                choice = Convert.ToInt32(Console.ReadLine());





                switch (choice)
                {

                    case 1:
                        DigitSum objdigitsum = new DigitSum();
                        objdigitsum.ReadData();
                        objdigitsum.FindDigitSum();
                        objdigitsum.DisplayData();

                        break;

                    case 2:
                        Prime a = new Prime();
                        a.ReadData();
                        a.CheckPrime();
                        a.DisplayData();

                        break;

                    case 3:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("wrong option");
                        break;


                }
            } while (true);
        }
    }
}
      
