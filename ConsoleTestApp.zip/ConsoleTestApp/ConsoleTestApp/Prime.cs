﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Prime
    {
        int n,no;
        string result;
        public void ReadData()
        {
            Console.WriteLine("Enter the no:");
           n = Convert.ToInt32(Console.ReadLine());

        }
        public void CheckPrime()
        {
            bool flag = true;
            for(no=2;no<=n-1;no++)
            {
                
                if(n%no==0)
                {
                    flag=false;
                    break;
                }
                
            }
            if(flag)
            {
                result = "prime";
            }
            else

            {
                result = "not prime";
            }

        }
        public void DisplayData()
        {
            
                Console.WriteLine("the no: {0} is {1}",n,result);
           
        }
        public static void Main()
        {
            Prime a = new Prime();
            a.ReadData();
            a.CheckPrime();
            a.DisplayData();
            Console.ReadKey();
            

        }
    }

}
