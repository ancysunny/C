﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class IntervalPrime
    {
        int interval1, interval2;
       

        public void ReadData()
        {
            Console.WriteLine("Enter the 1st Interval");
            interval1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the 2nd Interval");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }

       public Boolean FindPrime(int n)
        {
           int i;
           bool flag=true;
           for(i=2;i<n-1;i++)
           {
               if(n%i==0)
               {
                   flag = false;
                   break;
               }
           }
           return flag;
        }

        public void CheckInterval()
       {
            int i;
            for(i=interval1;i<=interval2;i++)
            {
                if(FindPrime(i))
                {
                    Console.WriteLine(i);
                }
   
            }
       }

        public static void Main()
        {
            IntervalPrime a = new IntervalPrime();
            a.ReadData();
            a.CheckInterval();
       
            Console.ReadKey();
        }
    }
}
