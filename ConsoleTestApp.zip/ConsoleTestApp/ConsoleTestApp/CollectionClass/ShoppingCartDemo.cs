﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.CollectionClassDemo
{
    class ItemDetails
    {
        
        public static void Main()
        {
            int total = 0;
            Hashtable Product = new Hashtable();
            Hashtable Cart = null;

            Product.Add(101, new Item { ProductID = 101, ProductName = "Lux", UnitPrice = 10, Quantity = 0, Amount = 0 });
            Product.Add(102, new Item { ProductID = 102, ProductName = "Liril", UnitPrice = 20, Quantity = 0, Amount = 0 });
            Product.Add(103, new Item { ProductID = 103, ProductName = "Pears", UnitPrice = 30, Quantity = 0, Amount = 0 });
            Product.Add(104, new Item { ProductID = 104, ProductName = "Santhoor", UnitPrice = 40, Quantity = 0, Amount = 0 });
            Product.Add(105, new Item { ProductID = 105, ProductName = "Dove", UnitPrice = 50, Quantity = 0, Amount = 0 });


            int choice;

            do
            {
                Console.WriteLine();
                Console.WriteLine("**************************");
                Console.WriteLine("1. Add To Cart");
                Console.WriteLine("2. View Cart");
                Console.WriteLine("3. CheckOut");
                Console.WriteLine("4. Exit");
                Console.WriteLine("**************************");
                Console.Write("Enter the option (1-4):");
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                switch(choice)
                {

                    case 1:

                        Console.WriteLine("          PRODUCT DETAILS");
                        Console.WriteLine("         -----------------\n");
                        Console.WriteLine(" Product ID| Product Name| Unit Price \n");
                        Item item;

                        if(Product !=null)
                        {
                            ICollection key = Product.Keys;
                            foreach(int k in key)
                            {
                                item = ((Item)Product[k]);
                                Console.WriteLine(" {0}  | {1}  |  {2} ", item.ProductID, item.ProductName, item.UnitPrice);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No product is available\n");
                        }
                        Console.Write("Enter the product Id:");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter the product Quantity you want:");
                        int quantity = Convert.ToInt32(Console.ReadLine());

                        if(Cart==null)
                        {
                            Cart = new Hashtable();
                        }
                        item = ((Item)Product[id]);
                        item.Quantity = quantity;
                        item.Amount = item.UnitPrice * item.Quantity;
                        Cart.Add(id, item);
                        Console.WriteLine("ADDED TO CART");
                        Console.ReadKey();

                        break;

                    case 2:

                        Console.WriteLine("                      MY CART");
                        Console.WriteLine("                     ----------\n");
                        Console.WriteLine(" Product ID  | Product Name  | Unit Price  | Quantity  | Amount \n");
                       

                        if(Cart !=null)
                        {
                            ICollection key = Cart.Keys;
                            foreach(int k in key)
                            {
                                item = ((Item)Cart[k]);
                                Console.WriteLine(" {0} |   {1}   | {2} | {3} | {4} ", item.ProductID, item.ProductName, item.UnitPrice,item.Quantity,item.Amount);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No product is available in the cart\n");
                        }
                        break;

                    case 3:

                        Console.WriteLine("                      PURCHASED PRODUCTS");
                        Console.WriteLine("                     --------------------\n");
                        Console.WriteLine(" Product ID  | Product Name  | Unit Price  | Quantity  | Amount \n");
                       

                        if(Cart !=null)
                        {
                            ICollection key = Cart.Keys;
                            foreach(int k in key)
                            {
                                item = ((Item)Cart[k]);
                                total += item.Amount;
                                Console.WriteLine(" {0} |   {1}   | {2} | {3} | {4} ", item.ProductID, item.ProductName, item.UnitPrice,item.Quantity,item.Amount);
                            }

                            Console.WriteLine("Total Amount = " + total);
                        }
                        break;

                    case 4:
                        System.Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Entry");
                        break;
                }
            } while (true);
        }
    
    }

    class Item
    {

        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int Amount { get; set; }

    }
}
