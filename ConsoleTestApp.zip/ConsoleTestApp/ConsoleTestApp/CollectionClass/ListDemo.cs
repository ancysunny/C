﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.CollectionClassDemo
{
    class ListDemo
    {

        public static void Main()
        {
            ArrayList();
            //HashTableDemo();
            Console.ReadKey();
        }

        private static void ArrayList()
        {
            List<String> names = new List<string>();
            names.Add("Sono Jaisal");
            names.Add("Ankit");
            names.Add("Ashwin");
            names.Add("Irfan");
            names.Add("Peter");
            //names.Remove("Ankit");
            //names.RemoveAt(1);
            //names.Reverse();
            //names.Sort();
            //names.RemoveRange(1, 2);

            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
        }


        //public static void HashTableDemo()
        //{
        //    Hashtable ht = new Hashtable();

        //    ht.Add("1.Anu");
        //    ht.Add("2.Ammu");
        //    ht.Add("3.Appu");
        //    ht.Add("4.Aaghuu");
            

        //}
        //public static void HashSetDemo()
        //{

        //}
    }
}
