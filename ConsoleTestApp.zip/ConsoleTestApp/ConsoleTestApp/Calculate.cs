﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Calculate
    {
        public static int sum(int a,int b)
        {
            int c = a + b;
            return c;
        }
        public int diff(int a,int b)
        {
            int c = a - b;
            return c;
        }
    }
}
