﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceDemo
    {
        public static void Main()
        {
            A a1 = new A();
            //a1.DisplayA();
            B b1 = new B(3,4);
            b1.DisplayA();
            b1.DisplayA();

            Console.ReadKey();




        }

        class A
        {
            public int val1;

            public A()
            {
                val1 = 20;
            }

            public A(int v1)
            {
                val1 = v1;
            }

            public virtual void DisplayA()
            {
                Console.WriteLine("I am in the base class a val1:" + val1);
            }
        }

        class B : A
        {
            int val2;

            public B()
            {
                val2 = 30;
            }
            public B(int v1, int v2) :base(v1)
            {
                val2 = v2;
            }

            public override void DisplayA()
            {
                Console.WriteLine("I am in the derived class val2:" + val2);
                Console.WriteLine("I am in the base class val1:" + val1);

            }

        }
    }
}
