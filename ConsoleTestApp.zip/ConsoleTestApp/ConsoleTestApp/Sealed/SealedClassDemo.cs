﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.SealedDemo
{
    //class SealedClassDemo
    //{

    //}

    //class util
    //{
    //    public virtual void Calculate()
    //    {

    //    }
    //}

    //class helper : util
    //{
    //     public sealed override void Calculate()
    //     {

    //     }
    //}

    //class staff : helper
    //{
    //    public override void Calculate()
    //    {
    //    }

    //}
   


}
