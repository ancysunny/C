﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryDemo;

namespace ConsoleTestApp
{
    class TestLibrary
    {
        public static void Main()
        {
            Calculator cal = new Calculator();
            cal.display();
            Console.ReadKey();
        }
    }
}
