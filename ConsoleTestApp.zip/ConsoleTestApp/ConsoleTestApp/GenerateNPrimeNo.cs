﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class GenerateNPrimeNo
    {
        static void Main(string[] args)
        {
            int num, i = 3, count, c;

            Console.WriteLine("Enter the number of prime numbers you want");
            num = Convert.ToInt32(Console.ReadLine());

            if (num >= 1)
            {

                Console.WriteLine("First " + num + " Prime Numbers are :\n");
                Console.WriteLine("2");
            }

            for (count = 2; count <= num; )
            {
                for (c = 2; c <= i - 1; c++)
                {
                    if (i % c == 0)
                        break;
                }
                if (c == i)
                {
                    Console.WriteLine("\n" + i);
                    count++;
                }
                i++;
            }
            Console.ReadKey();
        }
    }
}
