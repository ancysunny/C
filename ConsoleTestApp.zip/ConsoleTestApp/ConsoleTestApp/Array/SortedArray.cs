﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class SortedArray
    {
        public static void Main()
        {
            
            int[] values = new int[8];           
            int temp = 0;
            Console.WriteLine("Enter the Values:");

            for (int i = 0; i < values.Length; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("--------------------------------");
            Console.WriteLine("ARRAY");
            Console.WriteLine("--------------------------------");

            foreach (int val in values)
            {
                Console.Write(" " + val);
            }
            Console.WriteLine(" ");

            for (int i = 0; i < values.Length;i++ )
            {
                for (int j = i+1; j < values.Length; j++)
                {
                    if (values[i] > values[j])
                    {
                        temp = values[i];
                        values[i] = values[j];
                        values[j] = temp;                       
                    }                   
                }              
            }

            Console.WriteLine("--------------------------------");
            Console.WriteLine("SORTED ARRAY");
            Console.WriteLine("--------------------------------");

            foreach (int val in values)
            {
                Console.Write(" " + val);
            }
            Console.WriteLine(" ");

            Console.ReadKey();
        }
    }
}
