﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class ArraySum
    {
        public static void Main()
        {
            int sum = 0;
            int [] values;
            values = new int[6];
            Console.WriteLine("Enter the Values");

            for (int i = 0; i < values.Length; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());

            }
            Console.WriteLine("----------------------");
            Console.WriteLine("ARRAY");
            Console.WriteLine("----------------------");

            foreach (int val in values)
                {
                    Console.Write(" " + val);
                }
            Console.WriteLine(" ");
            

            for (int i = 0; i < values.Length; i++)
            {
                sum += values[i];

            }

            Console.WriteLine("ARRAY SUM : "+sum);
            Console.ReadKey();

        }

        
    }
}
