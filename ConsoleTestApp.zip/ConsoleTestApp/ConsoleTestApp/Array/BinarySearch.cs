﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Array
{
    class BinarySearch
    {
        public static void Main()
        {

            int[] values = new int[5];
            int temp = 0;
            int searchno;
            bool flag = false;
            Console.WriteLine("Enter the Values:");

            for (int i = 0; i < values.Length; i++)
            {
                values[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("--------------------------------");
            Console.WriteLine("ARRAY");
            Console.WriteLine("--------------------------------");

            foreach (int val in values)
            {
                Console.Write(" " + val);
            }
            Console.WriteLine(" ");

            for (int i = 0; i < values.Length; i++)
            {
                for (int j = i + 1; j < values.Length; j++)
                {
                    if (values[i] > values[j])
                    {
                        temp = values[i];
                        values[i] = values[j];
                        values[j] = temp;
                    }
                }
            }

            Console.WriteLine("--------------------------------");
            Console.WriteLine("SORTED ARRAY");
            Console.WriteLine("--------------------------------");

            foreach (int val in values)
            {
                Console.Write(" " + val);
            }
            Console.WriteLine(" ");


            Console.Write("Enter the number to be searched:");
            searchno = Convert.ToInt32(Console.ReadLine());

            int min = 0;
            int max = values.Length - 1;
            
            while(min<=max)
            {
                int middle = (min+max) / 2;
                if (searchno == values[middle])
                {
                    flag = true;
                    break;
                }
                else
                {
                    if (searchno < values[middle])
                    {
                        max = middle - 1;
                    }
                    else
                    {
                        min = middle + 1;
                    }
                }
            }         
                if (flag == true)
                {
                    Console.WriteLine("Search Successfull");
                }

                else
                {
                    Console.WriteLine("Search Unsuccessfull");
                }            
            Console.ReadKey();
        }
    }
}
