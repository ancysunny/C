﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Pattern5
    {
        int number;
        public void ReadData()
        {
            Console.Write("Enter the number : ");
            number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n");
        }


        public void print()
        {
            for (int no = 1; no <= number; no++)
            {
                if (no == 1 || no == number)
                {
                    for (int i = 1; i <= number; i++)
                    {
                        Console.Write(" * ");
                    }
                }
                else
                {
                    for (int j = 1; j <= number; j++)
                    {
                        if (j == 1 || j == number)
                        {
                            Console.Write(" * ");
                        }
                        else
                        {
                            Console.Write("   ");
                        }


                    }
                }

                Console.WriteLine("\n");
            }
        }

        public static void Main()
        {
            Pattern5 Objdigit1 = new Pattern5();
            Objdigit1.ReadData();
            Objdigit1.print();

            Console.ReadKey();
        }


    }
}
