﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AbstractDemo
    {
        public static void Main()
        {
            XYZ xyz = new XYZ();
            xyz.print();
            xyz.display();
            Console.ReadKey();
            
        }
    }

    abstract class ABC
    {
        public abstract void display();

        public void print()
        {
            Console.WriteLine("I am in print method");
        }          
    }

    class XYZ : ABC
    {
        public override void display()
        {
            Console.WriteLine("I am in display method");
        } 
    }
}
