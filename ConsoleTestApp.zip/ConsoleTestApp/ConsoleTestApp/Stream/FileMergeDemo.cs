﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp.Stream
{
    class FileMergeDemo
    {

        public static void Main()
        {
            string firstFilepath = "C:\\Users\\1028270\\Desktop\\ancysunny\\data.txt";
            string secondFilepath = "C:\\Users\\1028270\\Desktop\\ancysunny\\data1.txt";
            string outputFilePath = "C:\\Users\\1028270\\Desktop\\ancysunny\\file3.txt";


            String[] first = File.ReadAllLines(firstFilepath);
            String[] second = File.ReadAllLines(secondFilepath);

            using (StreamWriter writer = new StreamWriter(outputFilePath))
            {
                for(int i=0;i<first.Length;i++)
                {
                    for(int j=0;j<second.Length;j++)
                    {
                        writer.WriteLine("{0}\n{1}", first[i], second[j]);
                    }
                }
            }
            Console.WriteLine("Successfully merged");
            Console.ReadKey();

        }
    }
}
