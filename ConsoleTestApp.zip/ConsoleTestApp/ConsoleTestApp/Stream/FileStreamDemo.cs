﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleTestApp.Stream
{
    class FileStreamDemo
    {


        public static void Main()
        {
            FileStream datafile = new FileStream("C:\\Users\\1028270\\Desktop\\ancysunny\\data.txt", FileMode.OpenOrCreate);
            for(int ii=65;ii<=90;ii++)
            {
                datafile.WriteByte((byte)ii);
            }
            datafile.Close();
            FileStream datafile1 = new FileStream("C:\\Users\\1028270\\Desktop\\ancysunny\\data1.txt", FileMode.OpenOrCreate);
            for (int ii = 65; ii <= 90; ii++)
            {
                datafile1.WriteByte((byte)ii);
            }
            datafile1.Close();
            Console.WriteLine("File Created Successfully");
            Console.WriteLine("File read operation");

            FileStream dataOutFile = new FileStream("C:\\Users\\1028270\\Desktop\\ancysunny\\data.txt", FileMode.OpenOrCreate);
            int i = 0;
            while((i=dataOutFile.ReadByte())!= -1)
            {
                Console.Write((char)i);
            }

            dataOutFile.Close();
            Console.ReadKey();
        }
    }
}
