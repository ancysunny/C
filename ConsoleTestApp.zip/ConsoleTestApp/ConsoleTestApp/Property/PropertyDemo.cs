﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Property
{
    class PropertyDemo
    {
        public static void Main()
        {
            School s1 = new School();

            s1.StudentID = 001;
            s1.StudentName = "Anu";
            s1.StudentMark = 45;

            School s2 = new School();

            s2.StudentID = 002;
            s2.StudentName = "Appu";
            s2.StudentMark = 35;

            Console.WriteLine("Student ID :" + s1.StudentID);
            Console.WriteLine("Student Name :" + s1.StudentName);
            Console.WriteLine("Student Mark :" + s1.StudentMark);
            Console.WriteLine("");
            Console.WriteLine("Student ID :" + s2.StudentID);
            Console.WriteLine("Student Name :" + s2.StudentName);
            Console.WriteLine("Student Mark :" + s2.StudentMark);

            Console.ReadKey();
        }
    }



        class School
        {
            private int studentID;
            private string studentName;
            private int studentMark;

            public int StudentID
            {
                get { return studentID; }
                set { studentID = value; }
            }

            public string StudentName
            {
                get { return studentName; }
                set { studentName = value; }
            }

            public int StudentMark
            {
                get { return studentMark; }
                set { studentMark = value; }
            }
        }

    
            
 }


