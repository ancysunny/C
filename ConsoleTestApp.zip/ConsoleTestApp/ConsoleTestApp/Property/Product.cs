﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Property
{
    class Product
    {
        public readonly int ProductID;
        static int id = 101;
        public Product()
        {
            ProductID = id;
            id++;
        }

        private string productName;
        private int supplierID;
        private int price;

        public string ProductName
        {
            get {return productName ;}
            set {productName=value ;}
        }

        public int SupplierID
        {
            get { return supplierID; }
            set { supplierID = value; }
        }

        public int ProductPrice
        {
            get { return price; }
            set { price = value; }
        }

        public static void Main()
        {
            Product p1 = new Product();
            p1.ProductName="Vivel";
            p1.SupplierID=009;
            p1.ProductPrice=50;

            Product p2 = new Product();
            p2.ProductName = "Lux";
            p2.SupplierID = 007;
            p2.ProductPrice = 80;


            Console.WriteLine("Product ID: " + p1.ProductID);
            
            Console.WriteLine("Product Name: " + p1.ProductName);
            Console.WriteLine("Product Name: " + p1.SupplierID);
            Console.WriteLine("Product Name: " + p1.ProductPrice);

            Console.WriteLine(" ");

            Console.WriteLine("Product ID: " + p2.ProductID);
            Console.WriteLine("Product Name: " + p2.ProductName);
            Console.WriteLine("Product Name: " + p2.SupplierID);
            Console.WriteLine("Product Name: " + p2.ProductPrice);

            Console.ReadKey();
        }


    }


}
