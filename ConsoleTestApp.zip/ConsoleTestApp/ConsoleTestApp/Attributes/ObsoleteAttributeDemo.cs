﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Attributes
{
    //class ObsoleteAttributeDemo
    //{

    //    public static void Main()
    //    {
            
    //}


    //[Obsolete("depricated class")]

    //class Calculator
    //{
    //    [Obsolete("new method :int Add(List<int> numbers)")]

    //    public static int Add(int value1, int value2)
    //    {
    //        return (value1 + value2);
    //    }

    //    public static int Add(List<int> numbers)
    //    {
    //        int sum = 0;
    //        foreach (int number in numbers)
    //        {
    //            Console.WriteLine(number);
    //        }
    //    }
    //}
}
