﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddEven
    {
        int n;

        public void ReadData()
        {
            Console.WriteLine("Enter the No:");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void CheckData()
        {
            if (n%2==0)
            {
                Console.WriteLine(" even number");
            }
            else
            {
                Console.WriteLine(" odd number");
            }
        }

        public static void Main(string[] args)
        {
            OddEven ObjRes = new OddEven();
            ObjRes.ReadData();
            ObjRes.CheckData();
            Console.ReadKey();
        }
        

       
    }
}
