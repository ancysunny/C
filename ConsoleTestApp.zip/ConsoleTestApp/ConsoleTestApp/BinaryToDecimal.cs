﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class BinaryToDecimal
    {
        int BinaryNo;
        int DecimalNo;

        public void ReadData()
        {
            Console.Write("Enter the binary number:");
            BinaryNo =Convert.ToInt32(Console.ReadLine());
        }

        public void ConvertToDecimal()
        {
            int lastdigit;
            int i = 0;

            do
            {
                lastdigit = BinaryNo % 10;
                DecimalNo += lastdigit * (int) Math.Pow(2,i);
                BinaryNo /= 10;
                i++;
            } while(BinaryNo>0);

        }

        public void Display()
        {
            Console.Write("Decimal No : "+DecimalNo);
        }

        public static void Main()
        {
            BinaryToDecimal bindec = new BinaryToDecimal();
            bindec.ReadData();
            bindec.ConvertToDecimal();
            bindec.Display();

            Console.ReadKey();

        }
    }
}
