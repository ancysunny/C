﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Shape
    {
        public static void Display(double d)
        {
            double pi = 3.14;
            Console.WriteLine("Area of circle is :"+ pi*d*d);
        }
        public static void Display(int a)
        {
            Console.WriteLine("Area of square is :" + a * a);
        }
        public static void Display(int b, double h)
        {
            Console.WriteLine("Area of triangle is :" + 0.5 * b * h);
        }

        public static void Main()
        {

            Display(4);
            Display(10);
            Display(3, 8);

            Console.ReadKey();
        }

    }
}
