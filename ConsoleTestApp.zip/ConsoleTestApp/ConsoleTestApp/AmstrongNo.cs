﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class AmstrongNo
    {
        int n;
        int amstrongno=0;

        public void ReadData()
        {
            Console.Write("Enter the number: ");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void amstrong()
        {
            int lastdigit;

            int num = n;
            do
            {
                lastdigit = num % 10;
                amstrongno +=(int)Math.Pow(lastdigit,3);
                num /= 10;
            } while (num > 0);

        }

        public void Display()
        {
            if (amstrongno == n)
            {
                Console.Write("Amstrong No");
            }
            else
            {
                Console.Write("Not Amstrong No");
            }
        }

        public static void Main()
        {
            AmstrongNo am = new AmstrongNo();
            am.ReadData();
            am.amstrong();
            am.Display();

            Console.ReadKey();

        }
    }
}
