﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SingleDigitSum
    {
        int n;
        int digitSum=0;   
        int result=0;
        public void ReadData()
        {
            Console.Write("Enter the number: ");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void FindDigitSum()
        {
            int lastDigit;

            while (n > 0 || n>9)
            {
                lastDigit = n % 10;
                digitSum += lastDigit;
                n /= 10;
            } 
           
        }

        public void DisplayData()
        {
            Console.WriteLine("Digitsum: " + digitSum);
            
            
        }
        
        public static void Main()
        {
            SingleDigitSum objdigitsum = new SingleDigitSum();
            objdigitsum.ReadData();
            objdigitsum.FindDigitSum();
            objdigitsum.DisplayData();

            Console.ReadKey();
        }
    }
}
