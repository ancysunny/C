﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OperatorOverloadingDemo
    {

        public static void Main()
        {


        }
    }

    class DistaceDiff
    {
        int feet, inches;

        public void DisplayDistance()
        {
            Console.Write("feet: {0} inches: {1}", feet, inches);
        }

        public void ReadDistance()
        {
            Console.Write("feet: ");
            feet = Convert.ToInt32(Console.ReadLine());
            Console.Write("inches: ");
            inches = Convert.ToInt32(Console.ReadLine());
        }

        
    }
}
