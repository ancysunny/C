﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Reverse
    {

        int n;
        int ReverseNo=0;

        public void ReadData()
        {
            Console.Write("Enter the number:");
            n = Convert.ToInt32(Console.ReadLine());
        }

        public void ReverseNumber()
        {
            int ld;
            
            do
            {
                ld = n % 10;
                ReverseNo = ReverseNo * 10 + ld;
                n /= 10;
               
            } while (n > 0);

        }

        public void Display()
        {
            Console.Write("Reverse No : " + ReverseNo);
        }

        public static void Main()
        {
            Reverse rev = new Reverse();
            rev.ReadData();
            rev.ReverseNumber();
            rev.Display();

            Console.ReadKey();

        }
    }
}
