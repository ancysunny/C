﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class IntervalOdd
    {
        int interval1,interval2,i=0;

        public void ReadData()
        {
            Console.WriteLine("Enter the 1st Interval");
            interval1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the 2nd Interval");
            interval2 = Convert.ToInt32(Console.ReadLine());
            

        }

        public void FindOdd()
        {

            for (i=interval1;i<=interval2;i++)
            {
                if(i%2!=0)
                {
                    Console.WriteLine(i);
                }

            }

        }
        public static void Main(string[] args)
        {
            IntervalOdd abc = new IntervalOdd();
            abc.ReadData();
            Console.WriteLine("the odd numbers are:");
            abc.FindOdd();
            Console.ReadKey();
        }
    }
}
