﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp.Debugging
{
    class BreakPointDemo
    {

        public static void Main()
        {
            
            int j = 5;
            for (int i = 1; i <= 10; i++)
            {

                if (i % 2 == 0)
                {
                    Console.WriteLine("Even Number: "+i);
                    j += 1;
                }
                else
                {
                    Console.WriteLine("Odd Number: "+i);
                    j -= 1;
                }
            }

            Console.ReadKey();
        }
        
     
       
    }
}
