﻿CREATE TABLE [dbo].[student_personal]
(
	[student_id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [email] VARCHAR(150) NULL, 
    [mobileNumber] INT NULL, 
    [address] VARCHAR(500) NULL, 
    [dob] DATE NULL
    
)