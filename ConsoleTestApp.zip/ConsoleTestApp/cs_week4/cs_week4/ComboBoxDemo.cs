﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class ComboBoxDemo : Form
    {
        public ComboBoxDemo()
        {
            InitializeComponent();
        }

        private void cmbDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = cmbDepartments.Items[cmbDepartments.SelectedIndex].ToString();
            MessageBox.Show(selected);
        }

        private void ComboBoxDemo_Load(object sender, EventArgs e)
        {
           

            cmbDepartments.Items.Add("IT");
            cmbDepartments.Items.Add("AUTO");

            cmbDepartments.BackColor = System.Drawing.SystemColors.AppWorkspace;
        
        }


    }
}
