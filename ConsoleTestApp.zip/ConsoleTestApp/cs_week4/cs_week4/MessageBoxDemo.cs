﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class MessageBoxDemo : Form
    {
        public MessageBoxDemo()
        {
            InitializeComponent();
        }

        private void btnMessage1_Click(object sender, EventArgs e)
        {
            string message = "Hello";

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnMessage2_Click(object sender, EventArgs e)
        {
            string message = "Do You Want To Close ?";
            string title = "CloseWindow";

            MessageBoxButtons buttons = MessageBoxButtons.AbortRetryIgnore;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Error);

            if(result==DialogResult.Abort)
            {
                MessageBox.Show("Abort");
            }
            else if(result==DialogResult.Retry)
            {
                MessageBox.Show("Retry");
            }
            else
            {
                MessageBox.Show("Ignore");
            }
        }
    }
}
