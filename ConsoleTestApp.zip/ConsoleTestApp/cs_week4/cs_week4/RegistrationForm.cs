﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txtID.Text==string.Empty || txtName.Text==string.Empty || txtEmail.Text==string.Empty || txtMob.Text==string.Empty || txtAddress.Text==string.Empty)
            {
                lblMessage.Text = "Please enter the details!!!";
            }


            else
            {
                if (txtID.Text == string.Empty)
                {
                    lblMessage.Text = "Please enter the ID";
                }
                else
                {
                    string ID = txtID.Text.ToString();
                }


                if (txtName.Text == string.Empty)
                {
                    lblMessage.Text = "Please enter the Name";
                }
                else
                {
                    string Name = txtName.Text;
                }


                if (txtEmail.Text == string.Empty || !txtEmail.Text.Contains('@'))
                {
                    lblMessage.Text = "Please enter the valid Email";
                }
                else
                {
                    string Email = txtEmail.Text;
                }


                if (txtMob.Text == string.Empty || txtMob.Text.Length < 10 || txtMob.Text.Length > 10)
                {
                    lblMessage.Text = "Please enter the valid Mobile number";
                }
                else
                {
                    string Mobile = txtMob.Text.ToString();
                }


                if (txtAddress.Text == string.Empty)
                {

                    lblMessage.Text = "Please enter the Address";
                }
                else
                {
                    string Address = txtAddress.Text;
                }


                if (rbFemale.Checked == true)
                {
                    string Gender = "Female";
                }
                else
                {
                    string Gender = "Male";
                }
            }
            
        }
    }
}
