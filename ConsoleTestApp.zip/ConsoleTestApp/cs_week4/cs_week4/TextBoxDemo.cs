﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class TextBoxDemo : Form
    {
        public TextBoxDemo()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Character:" + txt1.TextLength);

            txt1.Text += "Quest";                                                                    //for appending text
            

           
        }
    }
}
