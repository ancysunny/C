﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class ColorDialogDemo : Form
    {
        public ColorDialogDemo()
        {
            InitializeComponent();
        }

        private void btnColorChange_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.ShowDialog();
            if(dlg.ShowDialog()==DialogResult.OK)
            {
                lblMessage.ForeColor = dlg.Color;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.ShowDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                lblMessage.BackColor = dlg.Color;
            }
        }

        private void ColorDialogDemo_Load(object sender, EventArgs e)
        {

        }
    }
}
