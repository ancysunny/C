﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class Calculator : Form
    {
        double number1;
        string operation;

        public Calculator()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToInt32(txtbox.Text);
            txtbox.Text = "";
            operation = "/";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtbox.Text = "";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if(txtbox.Text=="0" && txtbox.Text!=null)
            {
                txtbox.Text = "0";
            }
            else
            {
                txtbox.Text += "0";
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "1" && txtbox.Text != null)
            {
                txtbox.Text = "1";
            }
            else
            {
                txtbox.Text += "1";
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "2" && txtbox.Text != null)
            {
                txtbox.Text = "2";
            }
            else
            {
                txtbox.Text += "2";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "3" && txtbox.Text != null)
            {
                txtbox.Text = "3";
            }
            else
            {
                txtbox.Text += "3";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "4" && txtbox.Text != null)
            {
                txtbox.Text = "4";
            }
            else
            {
                txtbox.Text += "4";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "5" && txtbox.Text != null)
            {
                txtbox.Text = "5";
            }
            else
            {
                txtbox.Text += "5";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "6" && txtbox.Text != null)
            {
                txtbox.Text = "6";
            }
            else
            {
                txtbox.Text += "6";
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "7" && txtbox.Text != null)
            {
                txtbox.Text = "7";
            }
            else
            {
                txtbox.Text += "7";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "8" && txtbox.Text != null)
            {
                txtbox.Text = "8";
            }
            else
            {
                txtbox.Text += "8";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (txtbox.Text == "9" && txtbox.Text != null)
            {
                txtbox.Text = "9";
            }
            else
            {
                txtbox.Text += "9";
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToInt32(txtbox.Text);
            txtbox.Text = "";
            operation = "+";
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToInt32(txtbox.Text);
            txtbox.Text = "";
            operation = "-";
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToInt32(txtbox.Text);
            txtbox.Text = "";
            operation = "*";
        }

        private void btnEqualsTo_Click(object sender, EventArgs e)
        {
            double number2 = Convert.ToInt32(txtbox.Text);
            switch(operation)
            {
              
                case"+":
                    txtbox.Text = (number1 + number2).ToString();
                    break;

                case "-":
                    txtbox.Text = (number1 - number2).ToString();
                    break;

                case "*":
                    txtbox.Text = (number1 * number2).ToString();
                    break;

                case "/":
                    if (number2 == 0)
                    {
                        txtbox.Text = "Syntax Error";

                    }
                    else
                    {
                        txtbox.Text = (number1 / number2).ToString();
                    }
                    break;

                case "%":
                    txtbox.Text = (number1 % number2).ToString();
                    break;
                default:
                    break;
            }
        }

        private void btnPorS_Click(object sender, EventArgs e)
        {
            if (txtbox.Text.StartsWith("-"))
            {

                txtbox.Text = txtbox.Text.Substring(1);
            }
            else
            {

                txtbox.Text = "-" + txtbox.Text;
            }
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            txtbox.Text = ".";
        }
    }
}
