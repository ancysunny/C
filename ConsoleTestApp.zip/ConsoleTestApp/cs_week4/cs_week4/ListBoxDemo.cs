﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class ListBoxDemo : Form
    {
        public ListBoxDemo()
        {
            InitializeComponent();
        }

        private void lstDays_Load(object sender, EventArgs e)
        {
            lstDays.Items.Add("Sunday");
            lstDays.Items.Add("Monday");
            lstDays.Items.Add("Tuesday");
            lstDays.Items.Add("Wednesday");
            lstDays.Items.Add("Friday");
            lstDays.Items.Add("Saturday");
            lstDays.SelectionMode = SelectionMode.MultiSimple;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string items = "";
            foreach(var item in lstDays.SelectedItems)
            {
                items += item.ToString() +",";
            }
            MessageBox.Show(items);
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            foreach (object obj in lstDays.SelectedItems)
            {
                MessageBox.Show(obj.ToString());
            }
        }

        private void lstMonths_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void lstMonths_Click(object sender, EventArgs e)
        {

        }
    }
}