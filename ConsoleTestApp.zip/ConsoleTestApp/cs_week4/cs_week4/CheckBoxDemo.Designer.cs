﻿namespace cs_week4
{
    partial class CheckBoxDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ckboption1 = new System.Windows.Forms.CheckBox();
            this.ckboption2 = new System.Windows.Forms.CheckBox();
            this.ckboption3 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ckboption1
            // 
            this.ckboption1.AutoSize = true;
            this.ckboption1.Location = new System.Drawing.Point(221, 114);
            this.ckboption1.Name = "ckboption1";
            this.ckboption1.Size = new System.Drawing.Size(66, 17);
            this.ckboption1.TabIndex = 0;
            this.ckboption1.Text = "Reading";
            this.ckboption1.UseVisualStyleBackColor = true;
            this.ckboption1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // ckboption2
            // 
            this.ckboption2.AutoSize = true;
            this.ckboption2.Location = new System.Drawing.Point(221, 150);
            this.ckboption2.Name = "ckboption2";
            this.ckboption2.Size = new System.Drawing.Size(69, 17);
            this.ckboption2.TabIndex = 1;
            this.ckboption2.Text = "Browsing";
            this.ckboption2.UseVisualStyleBackColor = true;
            // 
            // ckboption3
            // 
            this.ckboption3.AutoSize = true;
            this.ckboption3.Location = new System.Drawing.Point(221, 186);
            this.ckboption3.Name = "ckboption3";
            this.ckboption3.Size = new System.Drawing.Size(59, 17);
            this.ckboption3.TabIndex = 2;
            this.ckboption3.Text = "Driving";
            this.ckboption3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(308, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 55);
            this.button1.TabIndex = 3;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CheckBoxDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 417);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ckboption3);
            this.Controls.Add(this.ckboption2);
            this.Controls.Add(this.ckboption1);
            this.Name = "CheckBoxDemo";
            this.Text = "CheckBoxDemo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ckboption1;
        private System.Windows.Forms.CheckBox ckboption2;
        private System.Windows.Forms.CheckBox ckboption3;
        private System.Windows.Forms.Button button1;
    }
}