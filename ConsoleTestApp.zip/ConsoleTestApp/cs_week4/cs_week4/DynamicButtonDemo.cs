﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class DynamicButtonDemo : Form
    {
        public DynamicButtonDemo()
        {
            InitializeComponent();
        }

        private void DynamicButtonDemo_Load(object sender, EventArgs e)
        {
            CreateDynamicButton();
        }

        private void CreateDynamicButton()
        {
            Button dynamicButton = new Button();                                                                   //create button


            dynamicButton.Height = 60;
            dynamicButton.Width = 400;
            dynamicButton.BackColor = Color.Green;
            dynamicButton.ForeColor = Color.Red;
            dynamicButton.Location = new Point(20,30);
            dynamicButton.Text = "I am Dynamic Button";

            Controls.Add(dynamicButton);                                                                            //to add into the form

            dynamicButton.Click += new EventHandler(DynamicButton_Click);                                          //delegate added
        }


        private void DynamicButton_Click(object sender,EventArgs e)
        {
            MessageBox.Show("Dynamic Button is Clicked");
        }
    }
}
