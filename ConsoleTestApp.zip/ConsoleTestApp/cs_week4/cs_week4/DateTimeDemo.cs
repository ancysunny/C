﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cs_week4
{
    public partial class DateTimeDemo : Form
    {
        public DateTimeDemo()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DateTimeDemo_Load(object sender, EventArgs e)
        {
            dtp.MinDate = new DateTime(2019, 5, 6);
            dtp.MaxDate = DateTime.Today;
        }

    }
}
