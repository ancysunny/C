﻿INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU101', N'Anu', 50, 40, 60, 150, N'PASS')
INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU102', N'Lissy', 40, 60, 60, 160, N'PASS')
INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU103', N'Amal', 20, 30, 20, 90, N'FAIL')
