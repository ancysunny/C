﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq
{
    


    public partial class Linq_Lambda : Form
    {

        Student[] studentArray={
                                   new Student() {StudentID=1,StudentName="ASD",Age=12},
                                   new Student() {StudentID=2,StudentName="DFGR",Age=12},
                                   new Student() {StudentID=3,StudentName="TYHH",Age=16},
                                   new Student() {StudentID=4,StudentName="VFG",Age=20},
                               };
        public Linq_Lambda()
        {
            InitializeComponent();
        }

        private void Linq_Lambda_Load(object sender, EventArgs e)
        {

        }

        private void btnLambda1_Click(object sender, EventArgs e)
        {
            List<Student> teenAger = studentArray.Where(s => s.StudentName == "ASD").ToList();                                  //Lambda Expression 1

            dgvLambda.DataSource = teenAger;
        }

        private void btnLambda2_Click(object sender, EventArgs e)
        {
            List<Student> teenAger = studentArray.Where(s => s.StudentID == 4).ToList();                                       //Lambda Expression 2

            dgvLambda.DataSource = teenAger;
        }

        private void btnLambda3_Click(object sender, EventArgs e)
        {
            List<Student> teenAger = studentArray.Where(s => s.Age == 12).ToList();                                           //Lambda Expression 3

            dgvLambda.DataSource = teenAger;
        }
    
  }

    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
    }


}
