﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq
{
    public partial class Linq_Array : Form
    {
        public Linq_Array()
        {
            InitializeComponent();
        }

        private void Linq_Array_Load(object sender, EventArgs e)
        {
            
        }

        private void LoadNumber()
        {
            int[] Numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };           //Data Source

            var LinqQury = from num in Numbers                           //LinqQuery
                           where (num % 2) == 0
                           select num;

            cmbNumbers.DataSource = LinqQury.ToList();


            //List<int> lstNumbers = LinqQury.ToList();

            //foreach (int val in lstNumbers)                               //LinqQuery Execution 
            //{
            //    //Console.WriteLine("val : " + val);
            //    cmbNumbers.Items.Add(val);
            //}
        }

        private void btnLoadNumber_Click(object sender, EventArgs e)
        {
            LoadNumber();
            
        }

        private void LoadNames()
        {
            string[] names = { "ASD", "WER", "FGR" ,"AQWE"};

            var myLinq = from name in names
                         where name.Contains('E') 
                         select name;

            foreach (var name in myLinq)
            {
                cmbNames.Items.Add(name);
            }
        }

        private void btnLoadNames_Click(object sender, EventArgs e)
        {
            LoadNames();
        }
    }
}
