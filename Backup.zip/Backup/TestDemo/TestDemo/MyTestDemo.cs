﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TestDemo
{
    public class MyTestDemo
    {

        public static void Main(string[] args)
        {
        }
        public int Add (int val1,int val2)
        {
            return val1 + val2;
        }

        public int Sub(int val1, int val2)
        {
            return val1 - val2;
        }
            
        
    }
}
