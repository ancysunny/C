﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDemo;

using NUnit.Framework;

namespace MyDemoTest
{
    [TestFixture]
    public class TestDemo2
    {
        [TestCase]
        public void Add()
        {
            MyTestDemo t1 = new MyTestDemo();
            Assert.AreEqual(41, t1.Add(21, 10));

        }

        [TestCase]
        public void Sub()
        {
            MyTestDemo t2 = new MyTestDemo();
            Assert.AreEqual(10, t2.Sub(20, 10));

        }
    }
}
