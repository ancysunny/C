﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestDemo;
using NUnit;

namespace MyDemoTest
{
    [TestClass]
    public class TestDemo1
    {
        [TestMethod]
        public void TestMethod1()
        {
            MyTestDemo t1 = new MyTestDemo();
            Assert.AreEqual(31, t1.Add(21, 10));

        }

        [TestMethod]
        public void TestMethod2()
        {
            MyTestDemo t2 = new MyTestDemo();
            Assert.AreEqual(10, t2.Sub(20, 10));

        }
    }
}
